-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2019 at 03:19 PM
-- Server version: 5.6.24
-- PHP Version: 5.5.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_dictionary`
--

CREATE TABLE IF NOT EXISTS `t_dictionary` (
  `id` int(11) NOT NULL,
  `type` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `t_dictionary`
--

INSERT INTO `t_dictionary` (`id`, `type`, `name`, `remark`) VALUES
(1, 'brand', 'Walmart', NULL),
(2, 'brand', 'Yellow', NULL),
(3, 'brand', 'H & M', NULL),
(4, 'brand', 'Black & White', NULL),
(5, 'dimensions', 'S', NULL),
(6, 'dimensions', 'M', NULL),
(7, 'dimensions', 'L', NULL),
(8, 'dimensions', 'XL', NULL),
(17, 'Category', 'Category1', NULL),
(18, 'Category', 'Category2', NULL),
(19, 'Category', 'Category3', NULL),
(20, 'Category', 'Category4', NULL),
(21, 'Category', 'Uncategorized', NULL),
(22, 'Category', 'Accessories', NULL),
(23, 'Category', 'New Arrival', NULL),
(24, 'Tag', 'Cloth', NULL),
(25, 'Tag', 'Blazer', NULL),
(26, 'Tag', 'Jacket', NULL),
(27, 'Tag', 'Polo Shirt', NULL),
(28, 'Tag', 'T-Shirt', NULL),
(29, 'Tag', 'Shoes', NULL),
(30, 'Tag', 'Pant', NULL),
(31, 'Tag', 'Party Dress', NULL),
(32, 'Tag', 'Coktail Dress', NULL),
(33, 'Tag', 'Sweater', NULL),
(34, 'Tag', 'Jeans', NULL),
(35, 'Type', 'Wooden', NULL),
(36, 'Type', 'Furnished', NULL),
(37, 'Type', 'Table', NULL),
(38, 'color', 'red', NULL),
(39, 'color', 'gray', NULL),
(40, 'color', 'black', NULL),
(42, 'color', 'pink', NULL),
(44, 'color', 'copper', NULL),
(45, 'color', 'blue', NULL),
(46, 'color', 'brown ', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `t_product`
--

CREATE TABLE IF NOT EXISTS `t_product` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` decimal(9,2) NOT NULL,
  `remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `t_product`
--

INSERT INTO `t_product` (`id`, `name`, `price`, `remark`) VALUES
(1, 'prod-01', '2.00', '123123'),
(2, 'prod-02999', '96.00', NULL),
(3, 'prod-03', '7.77', NULL),
(4, 'prod-04', '6.66', NULL),
(5, 'prod-05', '55.20', NULL),
(6, 'prod-06', '4.00', NULL),
(7, 'prod-07', '89.10', NULL),
(8, 'prod-08', '801.10', NULL),
(9, 'prod-09', '222.10', NULL),
(10, 'prod-10', '31.54', NULL),
(11, 'prod-11', '789.10', NULL),
(12, 'prod-12', '751.00', NULL),
(13, 'prod-13', '33.00', NULL),
(14, 'prod-13', '1414.00', '123123');

-- --------------------------------------------------------

--
-- Table structure for table `t_product_detail`
--

CREATE TABLE IF NOT EXISTS `t_product_detail` (
  `product_id` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `brand` int(11) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `weight` double NOT NULL,
  `dimensions` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `introduction` text COLLATE utf8_unicode_ci,
  `describe1` text COLLATE utf8_unicode_ci,
  `remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `t_product_detail`
--

INSERT INTO `t_product_detail` (`product_id`, `category`, `brand`, `type`, `weight`, `dimensions`, `color`, `introduction`, `describe1`, `remark`) VALUES
(2, 18, 2, 36, 55, '22 x 221 x 331 ', '46', 'Change2 :Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.', '2 ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla paExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. iatis unde omnis iste natus error sit voluptatem accusantium \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.\r\nCharacteristics :\r\nRsit amet, consectetur adipisicing elit, sed do eiusmod tempor inc.\r\nsunt in culpa qui officia deserunt mollit anim id est laborum. \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididu. ', NULL),
(3, 19, 3, 37, 111, '151 x 221 x 331 ', '40', 'Change3 :Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.', '3 ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla paExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. iatis unde omnis iste natus error sit voluptatem accusantium \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.\r\nCharacteristics :\r\nRsit amet, consectetur adipisicing elit, sed do eiusmod tempor inc.\r\nsunt in culpa qui officia deserunt mollit anim id est laborum. \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididu. ', NULL),
(4, 20, 4, 35, 123, '33 x 221 x 331 ', '40', 'Change4 :Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.', '4 ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla paExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. iatis unde omnis iste natus error sit voluptatem accusantium \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.\r\nCharacteristics :\r\nRsit amet, consectetur adipisicing elit, sed do eiusmod tempor inc.\r\nsunt in culpa qui officia deserunt mollit anim id est laborum. \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididu. ', NULL),
(5, 17, 1, 36, 34, '141 x 221 x 331 ', '42', 'Change5 :Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.', '5 ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla paExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. iatis unde omnis iste natus error sit voluptatem accusantium \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.\r\nCharacteristics :\r\nRsit amet, consectetur adipisicing elit, sed do eiusmod tempor inc.\r\nsunt in culpa qui officia deserunt mollit anim id est laborum. \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididu. ', NULL),
(6, 22, 2, 37, 343, '44 x 221 x 331 ', '44', 'Change6 :Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.', '6 ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla paExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. iatis unde omnis iste natus error sit voluptatem accusantium \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.\r\nCharacteristics :\r\nRsit amet, consectetur adipisicing elit, sed do eiusmod tempor inc.\r\nsunt in culpa qui officia deserunt mollit anim id est laborum. \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididu. ', NULL),
(7, 23, 3, 35, 121, '130 x 221 x 331 ', '44', 'Change7 :Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.', '7 ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla paExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. iatis unde omnis iste natus error sit voluptatem accusantium \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.\r\nCharacteristics :\r\nRsit amet, consectetur adipisicing elit, sed do eiusmod tempor inc.\r\nsunt in culpa qui officia deserunt mollit anim id est laborum. \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididu. ', NULL),
(8, 22, 4, 36, 69, '55 x 221 x 331 ', '45', 'Change8 :Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.', '8 ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla paExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. iatis unde omnis iste natus error sit voluptatem accusantium \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.\r\nCharacteristics :\r\nRsit amet, consectetur adipisicing elit, sed do eiusmod tempor inc.\r\nsunt in culpa qui officia deserunt mollit anim id est laborum. \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididu. ', NULL),
(9, 21, 1, 37, 65, '120 x 221 x 331 ', '46', 'Change9 :Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.', '9Lorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla paExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. iatis unde omnis iste natus error sit voluptatem accusantium \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.\r\nCharacteristics :\r\nRsit amet, consectetur adipisicing elit, sed do eiusmod tempor inc.\r\nsunt in culpa qui officia deserunt mollit anim id est laborum. \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididu. ', NULL),
(10, 20, 2, 36, 43, '66 x 221 x 331 ', '45', 'Change10 :Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.', '10Lorem1 ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla paExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. iatis unde omnis iste natus error sit voluptatem accusantium \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.\r\nCharacteristics :\r\nRsit amet, consectetur adipisicing elit, sed do eiusmod tempor inc.\r\nsunt in culpa qui officia deserunt mollit anim id est laborum. \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididu. ', NULL),
(11, 19, 3, 35, 12, '99 x 221 x 331 ', '44', 'Change11 :Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.', '11Lorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla paExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. iatis unde omnis iste natus error sit voluptatem accusantium \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.\r\nCharacteristics :\r\nRsit amet, consectetur adipisicing elit, sed do eiusmod tempor inc.\r\nsunt in culpa qui officia deserunt mollit anim id est laborum. \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididu. ', NULL),
(12, 18, 4, 36, 62, '77 x 221 x 331 ', '39', 'Change12 :Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.', '12Lorem1 ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla paExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. iatis unde omnis iste natus error sit voluptatem accusantium \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.\r\nCharacteristics :\r\nRsit amet, consectetur adipisicing elit, sed do eiusmod tempor inc.\r\nsunt in culpa qui officia deserunt mollit anim id est laborum. \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididu. ', NULL),
(13, 17, 3, 37, 1, '88 x 221 x 331 ', '42', 'Change13 :Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.', '13Lorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla paExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. iatis unde omnis iste natus error sit voluptatem accusantium \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.\r\nCharacteristics :\r\nRsit amet, consectetur adipisicing elit, sed do eiusmod tempor inc.\r\nsunt in culpa qui officia deserunt mollit anim id est laborum. \r\nLorem ipsum dolor sit amet, consec do eiusmod tincididu. ', NULL),
(1, 23, 1, 35, 24, '110 x 221 x 331 ', '46', 'a3', 'a4', NULL),
(14, 17, 1, 35, 24, '110 x 221 x 331 ', '38', 'b14', 'b14', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `t_user`
--

CREATE TABLE IF NOT EXISTS `t_user` (
  `id` int(10) unsigned NOT NULL,
  `username` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `pwd` varchar(18) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `t_user`
--

INSERT INTO `t_user` (`id`, `username`, `pwd`) VALUES
(1, 'wsm', '123456'),
(2, 'lp', '654321'),
(10, '11', '11');

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_product`
--
CREATE TABLE IF NOT EXISTS `v_product` (
`id` int(11)
,`name` varchar(255)
,`price` decimal(9,2)
,`remark1` varchar(255)
,`category` int(11)
,`brand` int(11)
,`type` int(11)
,`weight` double
,`dimensions` varchar(255)
,`color` varchar(255)
,`introduction` text
,`describe1` text
,`remark2` varchar(255)
);

-- --------------------------------------------------------

--
-- Structure for view `v_product`
--
DROP TABLE IF EXISTS `v_product`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_product` AS select `t_product`.`id` AS `id`,`t_product`.`name` AS `name`,`t_product`.`price` AS `price`,`t_product`.`remark` AS `remark1`,`t_product_detail`.`category` AS `category`,`t_product_detail`.`brand` AS `brand`,`t_product_detail`.`type` AS `type`,`t_product_detail`.`weight` AS `weight`,`t_product_detail`.`dimensions` AS `dimensions`,`t_product_detail`.`color` AS `color`,`t_product_detail`.`introduction` AS `introduction`,`t_product_detail`.`describe1` AS `describe1`,`t_product_detail`.`remark` AS `remark2` from (`t_product` join `t_product_detail`) where (`t_product`.`id` = `t_product_detail`.`product_id`);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t_dictionary`
--
ALTER TABLE `t_dictionary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_product`
--
ALTER TABLE `t_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_product_detail`
--
ALTER TABLE `t_product_detail`
  ADD KEY `t_product_detail_t_product_id_fk` (`product_id`);

--
-- Indexes for table `t_user`
--
ALTER TABLE `t_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_dictionary`
--
ALTER TABLE `t_dictionary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `t_product`
--
ALTER TABLE `t_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `t_user`
--
ALTER TABLE `t_user`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `t_product_detail`
--
ALTER TABLE `t_product_detail`
ADD CONSTRAINT `t_product_detail_t_product_id_fk` FOREIGN KEY (`product_id`) REFERENCES `t_product` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
