<?php
require './pdo.php';
?>
<?php  
$target_path = 'assets/img/products/';  

$target_path = $target_path.$_REQUEST["pro_name"].".jpg";
//$target_path = $target_path.'image1.jpg';      

echo $target_path;

Print_r(  getimagesize($_FILES["file"]["tmp_name"]));

if(move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {  
    echo "File uploaded successfully!";  
} else{  
    echo "Sorry, file not uploaded, please try again!";  
}  
?>
<input type="text" name="product_id" id="product_id" value="<?php echo  $_REQUEST["product_id"];?>">
<?php

$sql_p="UPDATE `mydb`.`t_product` t SET t.`name` = '".$_REQUEST["pro_name"]."', t.`price` =".$_REQUEST["pro_price"]." WHERE t.`id` =". $_REQUEST["product_id"];

$sql_pd="UPDATE `mydb`.`t_product_detail` t SET t.`category` = ".$_REQUEST["category"].",t.`color` =". $_REQUEST["color"].", t.`introduction` = '".$_REQUEST["introduction"]."',t.`describe1` ='".$_REQUEST["descript1"]."' WHERE t.`product_id` =". $_REQUEST["product_id"];

$link->query('SET NAMES UTF8');

$result = $link->query($sql_p);
$result = $link->query($sql_pd);

header('Location:product-details.php?product_id='.$_REQUEST["product_id"]."&file=".$temp_filename);
?>
