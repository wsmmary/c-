<?php

require './pdo.php';
$product_id=$_GET['product_id'];

$str = "select * from v_product where id=".$product_id;



$link->query('SET NAMES UTF8');

$result = $link->query($str);
$row = mysqli_fetch_assoc($result);


?>


<!doctype html>
<html class="no-js" lang="zxx">
 
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicons -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="assets/img/icon.png">

    <!-- ************************* CSS Files ************************* -->

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="assets/css/vendor.css">

    <!-- style css -->
    <link rel="stylesheet" href="assets/css/main.css">
</head>

<body>

    <!-- Preloader Start -->
    <div class="ft-preloader active">
        <div class="ft-preloader-inner h-100 d-flex align-items-center justify-content-center">
            <div class="ft-child ft-bounce1"></div>
            <div class="ft-child ft-bounce2"></div>
            <div class="ft-child ft-bounce3"></div>
        </div>
    </div>
    <!-- Preloader End -->

    <!-- Main Wrapper Start -->
    <div class="wrapper">
        <!-- Header Start -->
        <header class="header">
            <div class="header__inner fixed-header">
                <div class="header__main">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <div class="header__main-inner">
                                    <div class="header__main-left">
                                        <div class="logo">
                                            <a href="index.html" class="logo--normal">
                                                <img src="assets/img/logo/logo.png" alt="Logo">
                                            </a>
                                        </div>
                                    </div>
                                    <div class="header__main-center">
                                        <nav class="main-navigation text-center d-none d-lg-block">
                                            <ul class="mainmenu">
                                                <li class="mainmenu__item">
                                                    <a href="index.php" class="mainmenu__link">
                                                        <span class="mm-text">Home</span>
                                                    </a>
                                                </li>
                                                <li class="mainmenu__item">
                                                    <a href="shop.php" class="mainmenu__link">
                                                        <span class="mm-text">Shop</span>
                                                    </a>
                                                </li>
												
                                            </ul>
                                        </nav>
                                    </div>
                                    <div class="header__main-right">
                                        <div class="header-toolbar-wrap">
                                            <div class="header-toolbar">
<!--                                                <div class="header-toolbar__item header-toolbar--search-btn">-->
<!--                                                    <a href="#searchForm" class="header-toolbar__btn toolbar-btn">-->
<!--                                                        <i class="la la-search"></i>-->
<!--                                                    </a>-->
<!--                                                </div>-->
                                        
                                                <div class="header-toolbar__item d-block d-lg-none">
                                                    <a href="#offcanvasMenu" class="header-toolbar__btn toolbar-btn menu-btn">
                                                        <div class="hamburger-icon">
                                                            <span></span>
                                                            <span></span>
                                                            <span></span>
                                                            <span></span>
                                                            <span></span>
                                                            <span></span>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header End -->

        <!-- Breadcrumb area Start -->
        <section class="page-title-area bg-image ptb--80" data-bg-image="assets/img/bg/page_title_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center">
                        <h1 class="page-title">Product Details</h1>
                        <ul class="breadcrumb">
                            <li><a href="index.html">Home</a></li>
                            <li class="current"><span>Edit Product Details</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!-- Breadcrumb area End -->

        <!-- Main Content Wrapper Start -->
        <form  action="blank.php" method="post" enctype="multipart/form-data" >
        <div class="main-content-wrapper"><br>
         <table width="500" border="0" cellspacing="1" cellpadding="10" align="center">
		  <tbody>
          <TR><TD colspan="2"><input type="text" id="product_id" name="product_id" style="visibility: hidden;" VALUE="<?php echo $row['id']?>"></TD></TR>
			<tr>
			  <td align="right">Product name:</td>
			  <td><input type="text" id="pro_name" name="pro_name" value="<?php echo $row['name']?>"></td>
            </tr>
			<tr>
			  <td align="right">Product price:</td>
			  <td><input type="text" id="pro_price" name="pro_price" value="<?php echo $row['price']?>"></td>
			</tr>

            <tr>
                <td align="right">Product color:</td>
                <td><select name="color" id="color">

                        <option value ="<?php echo $row['color'];?>"><?php echo dicData($link,$row['color']);?></option>
                        <?php
                        $str="select * from t_dictionary where type='color'";
                        $link->query('SET NAMES UTF8');
                        $result=$link->query($str);

                        while($row1 = mysqli_fetch_assoc($result))
                        {
                        ?>
                            <option value ="<?php echo $row1['id']?>"><?php echo $row1['name']?></option>
                            <?php
                        }
                        ?>
                    </select></td>
            </tr>
			<tr>
                <td align="right">Product category:</td>
                <td><select name="category" id="category">
                        <option value ="<?php echo $row['category'];?>"><?php echo dicData($link,$row['category']);?></option>
                        <?php
                        $str="select * from t_dictionary where type='category'";
                        $link->query('SET NAMES UTF8');
                        $result=$link->query($str);

                        while($row1 = mysqli_fetch_assoc($result))
                        {
                            ?>
                            <option value ="<?php echo $row1['id']?>"><?php echo $row1['name']?></option>
                            <?php
                        }
                        ?>
            </tr>

			<tr>
			  <td align="right">Product introduction:</td>
			  <td><Textarea  name="introduction" style="width: 250px;height:80px;"><?php echo $row['introduction']?></Textarea ></td>
			</tr>
            <tr>
                <td align="right">Product descript:</td>
                <td><textarea name="descript1" style="width: 250px;height:80px;"><?php echo $row['describe1']?></textarea></td>
            </tr>
            <tr>
                <td align="right">Product image:</td>

                <td>    <input type="file" name="file" id="file"></td>
            </tr>            
			<tr>
			  <td colspan="2" align="center"><button type="submit" id="submit">Submit</button></td>

            <?php




//                $str= "UPDATE `mydb`.`t_product_detail` t SET t.`weight` =  WHERE t.`product_id` = 1 AND t.`category` = 17 AND t.`brand` = 1 AND t.`type` = 35 AND t.`weight` = 25 AND t.`dimensions` LIKE '110 x 221 x 331 ' ESCAPE '#' AND t.`color` LIKE '38' ESCAPE '#' AND t.`introduction` LIKE 'Change1 :Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.' ESCAPE '#' AND t.`describe1` LIKE '1 ipsum dolor sit amet, consec do eiusmod tincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniaLo ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla paExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. iatis unde omnis iste natus error sit voluptatem accusantium";

//                $link->query('SET NAMES UTF8');
//                $result=$link->query($str);

            ?>


            </tr>
		  </tbody>
		</table>
                    <div class="edit_frame"><br>
						
                              <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><br>
								<div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><br>
								<div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><br>
								<div>
								  <label for="select">&nbsp;&nbsp;</label>
                                  
                     			 </div><br>
								<div>&nbsp;&nbsp;
								  
								</div><br>
						<div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
                    </div>
        </div>
		</form>

       
 

    <!-- ************************* JS Files ************************* -->

    <!-- jQuery JS -->
    <script src="assets/js/vendor.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
</body>

</html>
