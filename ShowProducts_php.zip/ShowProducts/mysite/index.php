<?php
require './pdo.php';

?>


<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Home</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicons -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="assets/img/icon.png">

    <!-- ************************* CSS Files ************************* -->
    <!-- Vendor CSS -->
    <link rel="stylesheet" href="assets/css/vendor.css">

    <!-- style css -->
    <link rel="stylesheet" href="assets/css/main.css">
</head>

<body>

<!-- Preloader Start -->
<div class="ft-preloader active">
    <div class="ft-preloader-inner h-100 d-flex align-items-center justify-content-center">
        <div class="ft-child ft-bounce1"></div>
        <div class="ft-child ft-bounce2"></div>
        <div class="ft-child ft-bounce3"></div>
    </div>
</div>
<!-- Preloader End -->
<!-- Main Wrapper Start -->
<div class="wrapper">
<?php
if(isset($_COOKIE['user_id'])){
?>  
  <!-- Header Start -->
    <header class="header">
        <div class="header__inner fixed-header">
            <div class="header__main">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="header__main-inner">
                                <div class="header__main-left">
                                    <div class="logo">
                                        <a href="index.php" class="logo--normal">
                                            <img src="assets/img/logo/logo.png" alt="Logo">
                                        </a>
                                    </div>
                                </div>
                                <div class="header__main-center">
                                    <nav class="main-navigation text-center d-none d-lg-block">
                                        <ul class="mainmenu">
                                            <li class="mainmenu__item">
                                                <a href="index.php" class="mainmenu__link">
                                                    <span class="mm-text">Home</span>
                                                </a>
                                            </li>
                                            <li class="mainmenu__item">
                                                <a href="shop.php" class="mainmenu__link">
                                                    <span class="mm-text">Shop</span>
                                                </a>
                                            </li>
                                            <li class="mainmenu__item">
                                                <a href="logOut.php" class="mainmenu__link">
                                                    <span class="mm-text">Log out</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                                <div class="header__main-right">
                                    <div class="header-toolbar-wrap">
                                        <div class="header-toolbar">
                                            <div class="header-toolbar__item header-toolbar--search-btn">
                                                <a href="#searchForm" class="header-toolbar__btn toolbar-btn">
                                                    <i class="la la-search"></i>
                                                </a>
                                            </div>

                                            <div class="header-toolbar__item d-block d-lg-none">
                                                <a href="#offcanvasMenu" class="header-toolbar__btn toolbar-btn menu-btn">
                                                    <div class="hamburger-icon">
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header End -->
<?php
}else{
?>
    <!-- Header Start -->
    <header class="header">
        <div class="header__inner fixed-header">
            <div class="header__main">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="header__main-inner">
                                <div class="header__main-left">
                                    <div class="logo">
                                        <a href="index.php" class="logo--normal">
                                            <img src="assets/img/logo/logo.png" alt="Logo">
                                        </a>
                                    </div>
                                </div>
                                <div class="header__main-center">
                                    <nav class="main-navigation text-center d-none d-lg-block">
                                        <ul class="mainmenu">
                                            <li class="mainmenu__item">
                                                <a href="index.php" class="mainmenu__link">
                                                    <span class="mm-text">Home</span>
                                                </a>
                                            </li>
                                            <li class="mainmenu__item">
                                                <a href="shop.php" class="mainmenu__link">
                                                    <span class="mm-text">Shop</span>
                                                </a>
                                            </li>
                                            <li class="mainmenu__item">
                                                <a href="login.html" class="mainmenu__link">
                                                    <span class="mm-text">Log in</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                                <div class="header__main-right">
                                    <div class="header-toolbar-wrap">
                                        <div class="header-toolbar">
                                            <div class="header-toolbar__item header-toolbar--search-btn">
                                                <a href="#searchForm" class="header-toolbar__btn toolbar-btn">
                                                    <i class="la la-search"></i>
                                                </a>
                                            </div>

                                            <div class="header-toolbar__item d-block d-lg-none">
                                                <a href="#offcanvasMenu" class="header-toolbar__btn toolbar-btn menu-btn">
                                                    <div class="hamburger-icon">
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header End -->
<?php
}
?>
    <!-- Main Content Wrapper Start -->
    <main class="main-content-wrapper">
        <!-- Slider area Start -->
        <section class="homepage-slider mb--75 mb-md--55">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="element-carousel slick-right-bottom"
                             data-slick-options='{
                                "slidesToShow": 1,
                                "arrows": true,
                                "prevArrow": {"buttonClass": "slick-btn slick-prev", "iconClass": "la la-arrow-left" },
                                "nextArrow": {"buttonClass": "slick-btn slick-next", "iconClass": "la la-arrow-right" }
                            }'
                             data-slick-responsive='[{"breakpoint": 768, "settings": {"arrows": false}}]'>
                            <div class="item">
                                <div class="single-slide d-flex align-items-center bg-color" data-bg-color="#dbf3f2">
                                    <div class="row align-items-center no-gutters w-100">
                                        <div class="col-xl-7 col-md-6 mb-sm--50">
                                            <figure data-animation="fadeInUp" data-duration=".3s" data-delay=".3s" class="plr--15">
                                                <img src="assets/img/slider/slider-01-img-01.png" alt="Slider O1 image" class="mx-auto">
                                            </figure>
                                        </div>
                                        <div class="col-md-6 col-lg-5 offset-lg-1 offset-xl-0">
                                            <div class="slider-content">
                                                <div class="slider-content__text mb--40 mb-md--30">
                                                    <p class="mb--15" data-animation="fadeInUp" data-duration=".3s" data-delay=".3s">#New Treand</p>
                                                    <p class="mb--20" data-animation="fadeInUp" data-duration=".3s" data-delay=".3s">Enlight your world. Make yourself more bright.</p>
                                                    <h1 class="heading__primary lh-pt7" data-animation="fadeInUp" data-duration=".3s" data-delay=".3s">Abotar Lighting</h1>
                                                </div>
                                                <div class="slider-content__btn">
                                                    <a href="#" class="btn btn-outline btn-brw-2" data-animation="fadeInUp" data-duration=".3s" data-delay=".6s">Shop Now</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="single-slide d-flex align-items-center bg-color" data-bg-color="#dbf3f2">
                                    <div class="row align-items-center no-gutters w-100">
                                        <div class="col-xl-6 col-md-6 mb-sm--50 order-md-2">
                                            <figure data-animation="fadeInUp" data-duration=".3s" data-delay=".3s" class="pl-15 pr--60">
                                                <img src="assets/img/slider/slider-02-img-01.png" alt="Slider O1 image" class="mx-auto">
                                            </figure>
                                        </div>
                                        <div class="col-md-5 col-lg-5 offset-md-1 order-md-1">
                                            <div class="slider-content">
                                                <div class="slider-content__text border-color-2 mb--40 mb-md--30">
                                                    <p class="mb--15" data-animation="fadeInUp" data-duration=".3s" data-delay=".3s">#New Treand</p>
                                                    <p class="mb--20" data-animation="fadeInUp" data-duration=".3s" data-delay=".3s">Enlight your world. Make yourself more bright.</p>
                                                    <h1 class="heading__primary lh-pt7" data-animation="fadeInUp" data-duration=".3s" data-delay=".3s">Abotar Lighting</h1>
                                                </div>
                                                <div class="slider-content__btn">
                                                    <a href="#" class="btn btn-outline btn-brw-2 btn-brc-2" data-animation="fadeInUp" data-duration=".3s" data-delay=".6s">Shop Now</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Slider area End -->
        <!-- Top Sale Area Start -->
        <section class="top-sale-area mb--75 mb-md--55">
            <div class="container">
                <div class="row mb--35 mb-md--23">
                    <div class="col-12 text-center">
                        <h2>This Week Top Sales</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="element-carousel"
                             data-slick-options='{
                                "spaceBetween": 30,
                                "slidesToShow": 3
                            }'
                             data-slick-responsive='[
                                {"breakpoint": 768, "settings": {"slidesToShow": 2}},
                                {"breakpoint": 480, "settings": {"slidesToShow": 1}}
                            ]'>
                            <?php
                            $str="select * from v_product";
                            $link->query('SET NAMES UTF8');
                            $result=$link->query($str);
                            while($row = mysqli_fetch_assoc($result))
                            {
                            ?>
                            <div class="item">
                                <div class="ft-product">
                                    <div class="product-inner">
                                        <div class="product-image">
                                            <figure class="product-image--holder">
                                                <?php echo '<img src="'."assets/img/products/".$row['name'].'.jpg" alt="Product">' ?>
                                            </figure>
                                            <a href=<?php echo "product-details.php?product_id=".$row['id'];?> class="product-overlay"></a>

<!--                                            <div class="product-action">-->
<!--                                                <a data-toggle="modal" data-target="#productModal" class="action-btn">-->
<!--                                                    <i class="la la-eye"></i>-->
<!--                                                </a>-->
<!---->
<!--                                            </div>-->
                                        </div>
                                        <div class="product-info plr--20">



                                            <h3 class="product-title">
                                                  <a href=<?php echo "product-details.php?product_id=". $row['id']?>><?php echo $row['name'] ?></a>
                                            </h3>
                                            <div class="product-info-bottom">
                                                <div class="product-price-wrapper">
                                                    <span class="money"><?php echo $row['price'] ?></span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Top Sale Area End -->
        <!-- Feature Product Area Start -->
        <section class="feature-product-area mb--75 mb-md--55">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="feature-product bg-color" data-bg-color="#d7fbf9">
                            <div class="feature-product__inner bg-color" data-bg-color="#e9fefd">
                                <div class="feature-product__info">
                                    <p class="hastag">#New Style</p>
                                    <h2 class="feature-product__title">Luxry soft</h2>
                                    <a href="shop.php" class="feature-product__btn">Buy now</a>
                                </div>
                                <figure class="feature-product__image mb-sm--30">

                                        <img src="assets/img/products/feature-product-01.png" alt="Feature Product">

                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Product Tab Area End -->
        <!-- Brand Logo Area Start -->
        <div class="brand-logo-area mb--80 mb-md--60">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-12">
                        <div class="brand-log-wrapper bg-color ptb--75" data-bg-color="#e9fefd">
                            <div class="element-carousel"
                                 data-slick-options='{
                                    "slidesToShow": 5,
                                    "autoplay": true
                                }'
                                 data-slick-responsive='[
                                    {"breakpoint": 1200, "settings": {"slidesToShow": 4}},
                                    {"breakpoint": 992, "settings": {"slidesToShow": 3}},
                                    {"breakpoint": 768, "settings": {"slidesToShow": 2}},
                                    {"breakpoint": 480, "settings": {"slidesToShow": 1}}
                                ]'>
                                <div class="item">
                                    <figure>
                                        <img src="assets/img/brand/brand-01.png" alt="Brand" class="mx-auto">
                                    </figure>
                                </div>
                                <div class="item">
                                    <figure>
                                        <img src="assets/img/brand/brand-02.png" alt="Brand" class="mx-auto">
                                    </figure>
                                </div>
                                <div class="item">
                                    <figure>
                                        <img src="assets/img/brand/brand-03.png" alt="Brand" class="mx-auto">
                                    </figure>
                                </div>
                                <div class="item">
                                    <figure>
                                        <img src="assets/img/brand/brand-04.png" alt="Brand" class="mx-auto">
                                    </figure>
                                </div>
                                <div class="item">
                                    <figure>
                                        <img src="assets/img/brand/brand-05.png" alt="Brand" class="mx-auto">
                                    </figure>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Brand Logo Area End -->
        <!-- Best Sale Product Area Start -->
        <section class="best-sale-product-area mb--75 mb-md--55">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="best-sale-product bg-color" data-bg-color="#f7f8f9">
                            <div class="best-sale-product__inner bg-color" data-bg-color="#ffffff">
                                <figure class="best-sale-product__img">
                                        <img src="assets/img/products/best-product-01.png" alt="Best Sale Product">
                                </figure>
                                <div class="best-sale-product__info">
                                    <h2 class="best-sale-product__heading">
                                        <span class="best-sale-product__heading--main">Best Sale</span>
                                        <span class="best-sale-product__heading--sub">Get Best Discount</span>
                                    </h2>
                                    <p class="best-sale-product__desc">It is a long established fact that a reader will be distracted by the readable content</p>
                                    <a href="shop.php" class="btn btn-outline btn-size-md btn-color-primary btn-shape-round btn-hover-2">Shop Now</a>
                                </div>
                            </div>
                            <figure class="best-sale-product__top-image">
                                <img src="assets/img/others/1.png" alt="bg image">
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Best Sale Product Area End -->
        <!-- Blog Area Start -->
        <section class="blog-area mb--70 mb-md--50">
            <div class="container">
                <div class="row mb--35 mb-md--23">
                    <div class="col-12 text-center">
                        <h2>News &amp; Updates</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="element-carousel" data-slick-options='{
                                "spaceBetween": 30,
                                "slidesToShow": 3,
                                "slidesToScroll": 1
                            }'
                             data-slick-responsive='[
                                {"breakpoint": 992, "settings": {"slidesToShow": 2}},
                                {"breakpoint": 768, "settings": {"slidesToShow": 1}}
                            ]'>
                            <div class="item">
                                <article class="blog">
                                    <div class="blog__inner">
                                        <div class="blog__media">
                                            <figure class="image">
                                                <img src="assets/img/blog/blog-01.jpg" alt="Blog" class="w-100">
                                                <a href="#" class="item-overlay"></a>
                                            </figure>
                                        </div>
                                        <div class="blog__info">
                                            <h2 class="blog__title"><a href="#">There are many variations of passages of Lorem.</a></h2>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            <div class="item">
                                <article class="blog">
                                    <div class="blog__inner">
                                        <div class="blog__media">
                                            <figure class="image">
                                                <img src="assets/img/blog/blog-02.jpg" alt="Blog" class="w-100">
                                                <a href="#" class="item-overlay"></a>
                                            </figure>
                                        </div>
                                        <div class="blog__info">
                                            <h2 class="blog__title"><a href="#">There are many variations of passages of Lorem.</a></h2>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            <div class="item">
                                <article class="blog">
                                    <div class="blog__inner">
                                        <div class="blog__media">
                                            <figure class="image">
                                                <img src="assets/img/blog/blog-03.jpg" alt="Blog" class="w-100">
                                                <a href="#" class="item-overlay"></a>
                                            </figure>
                                        </div>
                                        <div class="blog__info">
                                            <h2 class="blog__title"><a href="#">There are many variations of passages of Lorem.</a></h2>
                                        </div>
                                    </div>
                                </article>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Blog Area End -->
    </main>
    <!-- Main Content Wrapper End -->



    <!-- Searchform Popup Start -->
    <div class="searchform__popup" id="searchForm">
        <a href="#" class="btn-close"><i class="la la-remove"></i></a>
        <div class="searchform__body">
            <p>Start typing and press Enter to search</p>
            <form class="searchform"  action="shop.php">
                <input type="text" name="popup-search" id="popup-search" class="searchform__input" placeholder="Search Entire Store...">
                <button type="submit" class="searchform__submit"><i class="la la-search"></i></button>
            </form>
        </div>
    </div>




    <!-- Searchform Popup End -->
    <!-- Qicuk View Modal Start -->
    <div class="modal fade product-modal" id="productModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class="la la-remove"></i></span>
                    </button>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="element-carousel slick-vertical-center"
                                 data-slick-options='{
                            "slidesToShow": 1,
                            "slidesToScroll": 1,
                            "arrows": true,
                            "prevArrow": {"buttonClass": "slick-btn slick-prev", "iconClass": "la la-angle-double-left" },
                            "nextArrow": {"buttonClass": "slick-btn slick-next", "iconClass": "la la-angle-double-right" }
                        }'>
                                <div class="product-image">
                                    <div class="product-image--holder">
                                        <a href="product-details.php">
                                            <img src="assets/img/products/prod-01.jpg" alt="Product Image" class="primary-image">
                                        </a>
                                    </div>
                                    <span class="product-badge sale">sale</span>
                                </div>
                                <div class="product-image">
                                    <div class="product-image--holder">
                                        <a href="product-details.php">
                                            <img src="assets/img/products/prod-02.jpg" alt="Product Image" class="primary-image">
                                        </a>
                                    </div>
                                    <span class="product-badge sale">sale</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="modal-box product-summary">
                                <div class="product-navigation text-right mb--20">
                                    <a href="#" class="prev"><i class="la la-angle-double-left"></i></a>
                                    <a href="#" class="next"><i class="la la-angle-double-right"></i></a>
                                </div>
                                <div class="product-rating d-flex mb--20">
                                    <div class="star-rating star-three">
                                        <span>Rated <strong class="rating">5.00</strong> out of 5</span>
                                    </div>
                                </div>
                                <h3 class="product-title mb--20">Golden Easy Spot Chair.</h3>
                                <p class="product-short-description mb--25">Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.</p>
                                <div class="product-price-wrapper mb--25">
                                    <span class="money">$200.00</span>
                                    <span class="price-separator">-</span>
                                    <span class="money">$400.00</span>
                                </div>
                                <form action="#" class="variation-form mb--30">
                                    <div class="product-color-variations d-flex align-items-center mb--20">
                                        <p class="variation-label">Color:</p>
                                        <div class="product-color-variation variation-wrapper">
                                            <div class="variation">
                                                <a class="product-color-variation-btn red selected" data-toggle="tooltip" data-placement="top" title="Red">
                                                    <span class="product-color-variation-label">Red</span>
                                                </a>
                                            </div>
                                            <div class="variation">
                                                <a class="product-color-variation-btn black" data-toggle="tooltip" data-placement="top" title="Black">
                                                    <span class="product-color-variation-label">Black</span>
                                                </a>
                                            </div>
                                            <div class="variation">
                                                <a class="product-color-variation-btn pink" data-toggle="tooltip" data-placement="top" title="Pink">
                                                    <span class="product-color-variation-label">Pink</span>
                                                </a>
                                            </div>
                                            <div class="variation">
                                                <a class="product-color-variation-btn blue" data-toggle="tooltip" data-placement="top" title="Blue">
                                                    <span class="product-color-variation-label">Blue</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-size-variations d-flex align-items-center mb--15">
                                        <p class="variation-label">Size:</p>
                                        <div class="product-size-variation variation-wrapper">
                                            <div class="variation">
                                                <a class="product-size-variation-btn selected" data-toggle="tooltip" data-placement="top" title="S">
                                                    <span class="product-size-variation-label">S</span>
                                                </a>
                                            </div>
                                            <div class="variation">
                                                <a class="product-size-variation-btn" data-toggle="tooltip" data-placement="top" title="M">
                                                    <span class="product-size-variation-label">M</span>
                                                </a>
                                            </div>
                                            <div class="variation">
                                                <a class="product-size-variation-btn" data-toggle="tooltip" data-placement="top" title="L">
                                                    <span class="product-size-variation-label">L</span>
                                                </a>
                                            </div>
                                            <div class="variation">
                                                <a class="product-size-variation-btn" data-toggle="tooltip" data-placement="top" title="XL">
                                                    <span class="product-size-variation-label">XL</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="" class="reset_variations">Clear</a>
                                </form>
                                <div class="product-action d-flex flex-sm-row flex-column align-items-sm-center align-items-start mb--30">
                                    <div class="quantity-wrapper d-flex align-items-center mr--30 mr-xs--0 mb-xs--30">
                                        <label class="quantity-label" for="quick-qty">Quantity:</label>
                                        <div class="quantity">
                                            <input type="number" class="quantity-input" name="qty" id="quick-qty" value="1" min="1">
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-size-sm btn-shape-square" onclick="window.location.href='#'">
                                        Add To Cart
                                    </button>
                                </div>
                                <div class="product-footer-meta">
                                    <p>
                                        <span>Category:</span>
                                        <a href="shop.php">Full Sweater</a>,
                                        <a href="shop.php">SweatShirt</a>,
                                        <a href="shop.php">Jacket</a>,
                                        <a href="shop.php">Blazer</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Qicuk View Modal End -->
    <!-- Global Overlay Start -->
    <div class="global-overlay"></div>
    <!-- Global Overlay End -->
    <!-- Global Overlay Start -->
    <a class="scroll-to-top" href=""><i class="la la-angle-double-up"></i></a>
    <!-- Global Overlay End -->
</div>
<!-- Main Wrapper End -->
<!-- ************************* JS Files ************************* -->
<!-- jQuery JS -->
<script src="assets/js/vendor.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>
</body>

</html>
