<?php
if(isset($_COOKIE['user_id'])){

    setcookie('user_id','',time()-3600);
}
?>
<html>
<head>
<style>
.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 30%;
}
</style>
</head>
<body><img src="assets/byebye.jpg" class="center"></body>
</html>