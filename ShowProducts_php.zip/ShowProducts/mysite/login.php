<?php

require './pdo.php';
if($link)
{
    if(isset($_POST["subl"]))
    {

      $name=$_POST["usernamel"];
      $password=$_POST["passwordl"];
      if($name==""||$password=="")//判断是否为空
      {
        echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please enter your information！"."\"".")".";"."</script>";
        echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."./login.html"."\""."</script>";
        exit;
      }
      $str="select pwd from t_user where username='$name'";

      $link->query('SET NAMES UTF8');
	  $result=$link->query($str);



		if($result){
		  $pass=mysqli_fetch_row($result);


		  if($pass[0]==$password)//判断密码与注册时密码是否一致
		  {
			setcookie('user_id',$name);
            
			echo"successful";
              $close=mysqli_close($link);
              if($close)
              {
//                  echo"数据库关闭";
                  echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."./index.php"."\""."</script>";

              }



          }
		  else
		  {  
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."error password or username！"."\"".")".";"."</script>";
			echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";
		  }
		}
	}
}
?>