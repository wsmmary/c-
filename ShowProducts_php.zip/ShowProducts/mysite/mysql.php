<?php
//1-define the connection
$mysqli=new mysqli('localhost','root','','mydb');

//var_dump($mysqli);

//check the connection
if($mysqli->connect_error){
	//output friendly message to user
	echo 'we are having a problem please check back later';
	//write to the log file.
	echo 'connection error';
	echo "Error:".$mysqli->connect_errno."\n";
	echo "Error:".$mysqli->connect_error."\n";
	exit; //equivalent to die;
}
//2-define the query
$query="select * from cds";

//3-capture the result
//$result=$mysqli->query($query);

//Check result
if(!$result=$mysqli->query($query)){
	echo 'message to the user';
	//write to the log file.
	echo 'connection error';
	echo "Error:".$mysqli->connect_errno."\n";
	echo "Error:".$mysqli->connect_error."\n";
	exit; //equivalent to die;
}

//4-User the result
echo '<br/>';
echo 'The number of rows: '.$result->num_rows;

echo '<br/>';
echo 'Fist row: '.$result->fetch_assoc()['TITLE'];

echo '<br/>';
echo 'Second row: '.$result->fetch_assoc()['TITLE'];

//set the pointer to a specific ROW
$result->data_seek(7);
echo '<br/>';
echo '8th row: '.$result->fetch_assoc()['TITLE'];

//reset the pointer to the first row
$result->data_seek(0);

echo '<br/>';
echo 'All CD Titles: '.'<br/>';

echo '<ul>';
for($i=0;$i<$result->num_rows;$i++){
	$row=$result->fetch_assoc();
	echo '<li>'.$row['TITLE'].'</li>';
}
echo '</ul>';

//clearup
$result->free();
$mysqli->close();



?>