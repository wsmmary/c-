<?php
header("Content-type:text/html;charset=utf-8");
//0.数据库配置信息
$db_host = 'localhost';
$db_user = 'root';
$db_pwd = '';
$db_name = 'mydb';


//1.PHP连接MySQL服务器
//$conn=mysqli_connect($db_host,$db_user,$db_pwd,$db_name);


$link=mysqli_connect($db_host,$db_user,$db_pwd,$db_name);



function dicData($link,$tmpData){
    $strTmp = "select * from t_dictionary where id=". $tmpData;

    $link->query('SET NAMES UTF8');

    $resultTmp = $link->query($strTmp);

    $rowTmp = mysqli_fetch_assoc($resultTmp);

    return $rowTmp['name'];
}
