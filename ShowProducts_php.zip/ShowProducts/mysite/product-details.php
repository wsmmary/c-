<?php

require './pdo.php';
$product_id=$_GET['product_id'];

$str = "select * from v_product where id=".$product_id;

$link->query('SET NAMES UTF8');

$result = $link->query($str);
$row = mysqli_fetch_assoc($result);



?>


<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicons -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="assets/img/icon.png">

    <!-- ************************* CSS Files ************************* -->

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="assets/css/vendor.css">

    <!-- style css -->
    <link rel="stylesheet" href="assets/css/main.css">
</head>

<body>

<!-- Preloader Start -->
<div class="ft-preloader active">
    <div class="ft-preloader-inner h-100 d-flex align-items-center justify-content-center">
        <div class="ft-child ft-bounce1"></div>
        <div class="ft-child ft-bounce2"></div>
        <div class="ft-child ft-bounce3"></div>
    </div>
</div>
<!-- Preloader End -->

<!-- Main Wrapper Start -->
<div class="wrapper">
<?php
if(isset($_COOKIE['user_id'])){
?>
    <!-- Header Start -->
    <header class="header">
        <div class="header__inner fixed-header">
            <div class="header__main">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="header__main-inner">
                                <div class="header__main-left">
                                    <div class="logo">
                                        <a href="index.php" class="logo--normal">
                                            <img src="assets/img/logo/logo.png" alt="Logo">
                                        </a>
                                    </div>
                                </div>
                                <div class="header__main-center">
                                    <nav class="main-navigation text-center d-none d-lg-block">
                                        <ul class="mainmenu">
                                            <li class="mainmenu__item">
                                                <a href="index.php" class="mainmenu__link">
                                                    <span class="mm-text">Home</span>
                                                </a>
                                            </li>
                                            <li class="mainmenu__item">
                                                <a href="shop.php" class="mainmenu__link">
                                                    <span class="mm-text">Shop</span>
                                                </a>
                                            </li>
											<li class="mainmenu__item">
                                                <a href=<?php echo "edit-product.php?product_id=".$product_id;?> class="mainmenu__link">

                                                <span class="mm-text">Edit</span>
                                                </a>
                                            </li>
                                            <li class="mainmenu__item">
											<a href="logOut.php" class="mainmenu__link">
                                                    <span class="mm-text"> Logout </span>
													</a>
                                            </li>


                                        </ul>
                                    </nav>
                                </div>
                                <div class="header__main-right">
                                    <div class="header-toolbar-wrap">
                                        <div class="header-toolbar">
                                            <div class="header-toolbar__item header-toolbar--search-btn">
                                                <a href="#searchForm" class="header-toolbar__btn toolbar-btn">
                                                    <i class="la la-search"></i>
                                                </a>
                                            </div>

                                            <div class="header-toolbar__item d-block d-lg-none">
                                                <a href="#offcanvasMenu" class="header-toolbar__btn toolbar-btn menu-btn">
                                                    <div class="hamburger-icon">
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header End -->
<?php
}
?>
    <!-- Breadcrumb area Start -->
    <section class="page-title-area bg-image ptb--80" data-bg-image="assets/img/bg/page_title_bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h1 class="page-title">Product Details</h1>
                    <ul class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li class="current"><span>Product Details</span></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb area End -->

    <!-- Main Content Wrapper Start -->
    <div class="main-content-wrapper">
        <div class="page-content-inner pt--80 pt-md--60">
            <div class="container">
                <div class="row no-gutters mb--80 mb-md--57">
                    <div class="col-lg-7 product-main-image">
                        <div class="product-image">
                            <div class="product-gallery vertical-slide-nav">
                                <div class="product-gallery__large-image mb-sm--30">
                                    <div class="product-gallery__wrapper">
                                        <div class="element-carousel main-slider image-popup"
                                             data-slick-options='{
                                                "slidesToShow": 1,
                                                "slidesToScroll": 1,
                                                "infinite": true,
                                                "arrows": false,
                                                "asNavFor": ".nav-slider"
                                            }'>
                                            <figure class="product-gallery__image zoom">
                                                <?php echo '<img src="'."assets/img/products/".$row['name'].'.jpg" alt="Product">' ?>
                                                <span class="product-badge sale">Sale</span>

                                            </figure>
                                            <figure class="product-gallery__image zoom">
                                                <?php echo '<img src="'."assets/img/products/".$row['name'].'-100x100.jpg" alt="Product">' ?>
                                                <span class="product-badge sale">Sale</span>

                                            </figure>
                                            <figure class="product-gallery__image zoom">
                                                <?php echo '<img src="'."assets/img/products/".$row['name'].'-270x300.jpg" alt="Product">' ?>
                                                <span class="product-badge sale">Sale</span>

                                            </figure>

<!--                                            </figure>-->
<!--                                            <figure class="product-gallery__image zoom">-->
<!--                                                <img src="assets/img/products/prod-04-700x778.png" alt="Product">-->
<!--                                                <span class="product-badge sale">Sale</span>-->
<!---->
<!--                                            </figure>-->
                                        </div>
                                    </div>
                                </div>
                                <div class="product-gallery__nav-image">
                                    <div class="element-carousel nav-slider product-slide-nav slick-center-bottom"
                                         data-slick-options='{
                                            "spaceBetween": 10,
                                            "slidesToShow": 3,
                                            "slidesToScroll": 1,
                                            "vertical": true,
                                            "swipe": true,
                                            "verticalSwiping": true,
                                            "infinite": true,
                                            "focusOnSelect": true,
                                            "asNavFor": ".main-slider",
                                            "arrows": true,
                                            "prevArrow": {"buttonClass": "slick-btn slick-prev", "iconClass": "la la-angle-up" },
                                            "nextArrow": {"buttonClass": "slick-btn slick-next", "iconClass": "la la-angle-down" }
                                        }'
                                         data-slick-responsive='[
                                            {
                                                "breakpoint":1200,
                                                "settings": {
                                                    "slidesToShow": 2
                                                }
                                            },
                                            {
                                                "breakpoint":992,
                                                "settings": {
                                                    "slidesToShow": 3
                                                }
                                            },
                                            {
                                                "breakpoint":767,
                                                "settings": {
                                                    "slidesToShow": 4,
                                                    "vertical": false
                                                }
                                            },
                                            {
                                                "breakpoint":575,
                                                "settings": {
                                                    "slidesToShow": 3,
                                                    "vertical": false
                                                }
                                            },
                                            {
                                                "breakpoint":480,
                                                "settings": {
                                                    "slidesToShow": 2,
                                                    "vertical": false
                                                }
                                            }
                                        ]'>
                                        <figure class="product-gallery__nav-image--single">
                                            <?php echo '<img src="'."assets/img/products/".$row['name'].'.jpg" alt="Product">' ?>
                                        </figure>
                                        <figure class="product-gallery__image zoom">
                                            <?php echo '<img src="'."assets/img/products/".$row['name'].'-100x100.jpg" alt="Product">' ?>
                                            <span class="product-badge sale">Sale</span>

                                        </figure>
                                        <figure class="product-gallery__image zoom">
                                            <?php echo '<img src="'."assets/img/products/".$row['name'].'-270x300.jpg" alt="Product">' ?>
                                            <span class="product-badge sale">Sale</span>

                                        </figure>
<!--                                        <figure class="product-gallery__nav-image--single">-->
<!--                                            <img src="assets/img/products/prod-04-、、、、.jpg" alt="Products">-->
<!--                                        </figure>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 offset-xl-1 col-lg-5 product-main-details mt-md--50">
                        <div class="product-summary pl-lg--30 pl-md--0">

                            <h3 class="product-title mb--20"><?php echo $row['name']?></h3>
                            <p class="product-short-description mb--20"><?php echo $row['introduction']?></p>
                            <div class="product-price-wrapper mb--25">
                                <span class="money">$ <?php echo $row['price']?></span>
                                <!--                                    <span class="price-separator">-</span>-->
                                <!--                                    <span class="money">$400.00</span>-->
                            </div>

                            <div class="product-footer-meta">
                                <p><span>Category:
                                        <?php

                                        echo dicData($link,$row['category']);
                                        ?>
                                    </span>
                                    <a href="shop.php"></a>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center mb--77 mb-md--57">
                    <div class="col-12">
                        <div class="tab-style-2">
                            <div class="nav nav-tabs mb--35 mb-sm--25" id="product-tab" role="tablist">
                                <a class="nav-link active" id="nav-description-tab" data-toggle="tab" href="#nav-description" role="tab" aria-selected="true">
                                    <span>Description</span>
                                </a>
                                <a class="nav-link" id="nav-info-tab" data-toggle="tab" href="#nav-info" role="tab" aria-selected="true">
                                    <span>Additional Information</span>
                                </a>

                            </div>
                            <div class="tab-content" id="product-tabContent">
                                <div class="tab-pane fade show active" id="nav-description" role="tabpanel" aria-labelledby="nav-description-tab">
                                    <div class="product-description">
                                        <?php echo $row['describe1']?>


                                    </div>
                                </div>
                                <div class="tab-pane fade" id="nav-info" role="tabpanel" aria-labelledby="nav-info-tab">
                                    <div class="table-content table-responsive">
                                        <table class="table shop_attributes">
                                            <tbody>
                                            <tr>
                                                <th>Weight</th>
                                                <td><?php echo $row['weight']?> kg</td>
                                            </tr>
                                            <tr>
                                                <th>Dimensions</th>
                                                <td><?php echo $row['dimensions']?> cm</td>
                                            </tr>
                                            <tr>
                                                <th>Color</th>
                                                <td>

                                                    <?php echo dicData($link,$row['color']);?>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Main Content Wrapper End -->





    <!-- Searchform Popup Start -->
    <div class="searchform__popup" id="searchForm">
        <a href="#" class="btn-close"><i class="la la-remove"></i></a>
        <div class="searchform__body">
            <p>Start typing and press Enter to search</p>
            <form class="searchform"  action="shop.php">
                <input type="text" name="popup-search" id="popup-search" class="searchform__input" placeholder="Search Entire Store...">
                <button type="submit" class="searchform__submit"><i class="la la-search"></i></button>
            </form>
        </div>
    </div>

    <!-- Searchform Popup End -->


    <!-- Global Overlay Start -->
    <div class="global-overlay"></div>
    <!-- Global Overlay End -->

    <!-- Global Overlay Start -->
    <a class="scroll-to-top" href=""><i class="la la-angle-double-up"></i></a>
    <!-- Global Overlay End -->
</div>
<!-- Main Wrapper End -->


<!-- ************************* JS Files ************************* -->

<!-- jQuery JS -->
<script src="assets/js/vendor.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>
</body>

</html>

