<?php
$link=mysqli_connect("localhost:3306","root","","mydb");
header("Content-type:text/html;charset=utf-8");
if($link)
  {  
     //echo"选择数据库成功！";
      if(isset($_POST["sub"]))
      {
        $name=$_POST["username"];
        $password1=$_POST["password"];
        $password2=$_POST["password2"];
        if($name==""||$password1=="")
        {
          echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."please enter the information！"."\"".")".";"."</script>";
          echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."./register.html"."\""."</script>";
          exit;
        }
        if($password1==$password2)
        {
        $str="select count(*) from t_user where username="."'"."$name"."'";
		$link->query('set names utf8;');
        $result=$link->query($str);
        $pass=mysqli_fetch_row($result);
        $pa=$pass[0];

        if($pa==1)
        {
        
        echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."The account name is used"."\"".")".";"."</script>";
        echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."./register.html"."\""."</script>";
        exit; 
        }
        
        
        $sql="insert into t_user (username,pwd) VALUES ('$name','$password1')";
        //echo"$sql";
        $link->query('SET NAMES UTF8');
		$link->query($sql);
        $close=mysqli_close($link);
        if($close)
        {
          //echo"数据库关闭";
          //echo"注册成功！";
          echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."./return.html"."\""."</script>";
        }
        }
        else
        {
          echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."The differenet password"."\"".")".";"."</script>";
          echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."./register.html"."\""."</script>";
        }
      }
  }
?>