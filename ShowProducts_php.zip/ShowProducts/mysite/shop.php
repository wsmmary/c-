﻿<?php
//类的用法
// 读取分页类
require './pdo.php';

require './pager.class.php';

///////////////////与分页有关//////////////////////////////
// 这是一个sql查询语句，并得到查询结果


if (is_array($_GET) && count($_GET) > 0) {
    // isset监测变量是否有设置
    if (isset($_GET['Category'])) {
        $Category=$_GET['Category'];
        $sql = "select * from v_product  where category = ".$Category;

    }elseif(isset($_GET['brand'])) {
        $brand=$_GET['brand'];
        $sql = "select * from v_product  where brand = ".$brand;

    }elseif(isset($_GET['color'])) {
        $color=$_GET['color'];
        $sql = "select * from v_product  where color = ".$color;

    }elseif(isset($_GET['priceLow'])) {
        if (isset($_GET['priceHigh'])){
            $priceLow=$_GET['priceLow'];
            $priceHigh=$_GET['priceHigh'];

            $sql = "select * from v_product  where price >= ".$priceLow." and price<=".$priceHigh;
        }else{
            $priceLow=$_GET['priceLow'];
            $sql = "select * from v_product  where price >= ".$priceLow;

        }
    }elseif(isset($_GET['popup-search'])) {
        $popupsearch=$_GET['popup-search'];
        $sql = "select * from v_product  where name like  '%".$popupsearch."%'";


    }else{
        $sql = "select * from v_product ";
    }
}else{
    $sql = "select * from v_product ";
}


// 分页初始化
$page = new pager($link,$sql,9);
// 9是每页显示的数量

$result=$link->query($page->sqlquery());

//while($info = mysqli_fetch_assoc($result)){
//
//    echo $info["id"]."<br/>";

?>
<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicons -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="assets/img/icon.png">

    <!-- ************************* CSS Files ************************* -->

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="assets/css/vendor.css">

    <!-- style css -->
    <link rel="stylesheet" href="assets/css/main.css">
</head>

<body>

<!-- Preloader Start -->
<div class="ft-preloader active">
    <div class="ft-preloader-inner h-100 d-flex align-items-center justify-content-center">
        <div class="ft-child ft-bounce1"></div>
        <div class="ft-child ft-bounce2"></div>
        <div class="ft-child ft-bounce3"></div>
    </div>
</div>
<!-- Preloader End -->

<!-- Main Wrapper Start -->
<div class="wrapper">
<?php
if(isset($_COOKIE['user_id'])){
?>
    <!-- Header Start -->
    <header class="header">
        <div class="header__inner fixed-header">
            <div class="header__main">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="header__main-inner">
                                <div class="header__main-left">
                                    <div class="logo">
                                        <a href="index.php" class="logo--normal">
                                            <img src="assets/img/logo/logo.png" alt="Logo">
                                        </a>
                                    </div>
                                </div>
                                <div class="header__main-center">
                                    <nav class="main-navigation text-center d-none d-lg-block">
                                        <ul class="mainmenu">
                                            <li class="mainmenu__item">
                                                <a href="index.php" class="mainmenu__link">
                                                    <span class="mm-text">Home</span>
                                                </a>
                                            </li>
                                            <li class="mainmenu__item">
                                                <a href="shop.php" class="mainmenu__link">
                                                    <span class="mm-text">Shop</span>
                                                </a>
                                            </li>
                                            <li class="mainmenu__item">
											<a href="logOut.php" class="mainmenu__link">
                                                    <span class="mm-text"> Logout </span>
													</a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                                <div class="header__main-right">
                                    <div class="header-toolbar-wrap">
                                        <div class="header-toolbar">
                                            <div class="header-toolbar__item header-toolbar--search-btn">
                                                <a href="#searchForm" class="header-toolbar__btn toolbar-btn">
                                                    <i class="la la-search"></i>
                                                </a>
                                            </div>
                                            <div class="header-toolbar__item header-toolbar--minicart-btn">

                                            </div>
                                            <div class="header-toolbar__item d-block d-lg-none">
                                                <a href="#offcanvasMenu" class="header-toolbar__btn toolbar-btn menu-btn">
                                                    <div class="hamburger-icon">
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header End -->
<?php
}else{
?>
    <!-- Header Start -->
    <header class="header">
        <div class="header__inner fixed-header">
            <div class="header__main">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="header__main-inner">
                                <div class="header__main-left">
                                    <div class="logo">
                                        <a href="index.php" class="logo--normal">
                                            <img src="assets/img/logo/logo.png" alt="Logo">
                                        </a>
                                    </div>
                                </div>
                                <div class="header__main-center">
                                    <nav class="main-navigation text-center d-none d-lg-block">
                                        <ul class="mainmenu">
                                            <li class="mainmenu__item">
                                                <a href="index.php" class="mainmenu__link">
                                                    <span class="mm-text">Home</span>
                                                </a>
                                            </li>
                                            <li class="mainmenu__item">
                                                <a href="shop.php" class="mainmenu__link">
                                                    <span class="mm-text">Shop</span>
                                                </a>
                                            </li>
                                            <li class="mainmenu__item">
											<a href="login.html" class="mainmenu__link">
                                                    <span class="mm-text"> Login </span>
													</a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                                <div class="header__main-right">
                                    <div class="header-toolbar-wrap">
                                        <div class="header-toolbar">
                                            <div class="header-toolbar__item header-toolbar--search-btn">
                                                <a href="#searchForm" class="header-toolbar__btn toolbar-btn">
                                                    <i class="la la-search"></i>
                                                </a>
                                            </div>
                                            <div class="header-toolbar__item header-toolbar--minicart-btn">

                                            </div>
                                            <div class="header-toolbar__item d-block d-lg-none">
                                                <a href="#offcanvasMenu" class="header-toolbar__btn toolbar-btn menu-btn">
                                                    <div class="hamburger-icon">
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                        <span></span>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header End -->
<?php
}
?>
    <!-- Breadcrumb area Start -->
    <section class="page-title-area bg-image ptb--80" data-bg-image="assets/img/bg/page_title_bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h1 class="page-title">Shop Left Sidebar</h1>
                    <ul class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li class="current"><span>Shop Left Sidebar</span></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb area End -->

    <!-- Main Content Wrapper Start -->
    <div  class="main-content-wrapper">
        <div class="shop-page-wrapper ptb--80">
            <div class="container">
                <div class="row">

                    <div class="col-xl-9 col-lg-8 order-lg-2 mb-md--50">
                        <div class="shop-products">
                            <div class="row">
                                <?php
                                while($row = mysqli_fetch_assoc($result)){
                                    ?>
                                    <div class="col-xl-4 col-sm-6 mb--50">
                                        <div class="ft-product">
                                            <div class="product-inner">
                                                <div class="product-image">
                                                    <figure class="product-image--holder">

                                                        <?php echo '<img src="'."assets/img/products/".$row['name'].'.jpg" alt="Product">' ?>

                                                    </figure>

                                                    <a href=<?php echo "product-details.php?product_id=".$row['id'];?> class="product-overlay"></a>

                                                    </a>

                                                </div>
                                                <div class="product-info">
                                                    <div class="product-category">
<!--                                                        <a href="product-details.html">-->
                                                            <?php
                                                            echo dicData($link,$row['category']);
                                                            ?>
<!--                                                        </a>-->
                                                    </div>
                                                    <h3 class="product-title">
                                                        <a href=<?php echo "product-details.php?product_id=". $row['id']?>><?php echo $row['name'] ?></a>
                                                        </h3>
                                                    <div class="product-info-bottom">
                                                        <div class="product-price-wrapper">
                                                            <span class="money">$<?php echo $row['price']?></span>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>

                        <nav class="pagination-wrap">
                            <ul class="pagination">
                                <?php
                                echo $page->set_page_info();
                                ?>
                            </ul>

                        </nav>
                    </div>



                    <!--                      左侧菜单-->
                    <div class="col-xl-3 col-lg-4 order-lg-1">
                        <aside class="shop-sidebar">
<!--                            Category-->
                            <div class="shop-widget mb--40">
                                <h3 class="widget-title mb--25">Category</h3>
                                <ul class="widget-list category-list">
                                    <?php
                                        $str="select * from t_dictionary where type='Category'";
                                        $link->query('SET NAMES UTF8');
                                        $tmpResult=$link->query($str);
                                        while($tmpRow = mysqli_fetch_assoc($tmpResult))
                                        {
                                    ?>
                                    <li>
                                        <a href=<?php echo "shop.php?Category=". $tmpRow['id']?>><?php echo $tmpRow['name']?> </a>
                                    </li>
                                        <?php
                                        }
                                    ?>

                                </ul>
                            </div>
<!--                            color-->
                            <div class="shop-widget mb--40">
                                <h3 class="widget-title mb--30">Color</h3>
                                <div class="widget-color">

                                    <?php
                                    $str="select * from t_dictionary where type='color'";
                                    $link->query('SET NAMES UTF8');
                                    $tmpResult=$link->query($str);
                                    while($tmpRow = mysqli_fetch_assoc($tmpResult))
                                    {
                                        ?>

                                            <a href=<?php echo "shop.php?color=". $tmpRow['id']?> class="<?php echo $tmpRow['name']?>"><?php echo $tmpRow['name']?></a>

                                        <?php
                                    }
                                    ?>


                                </div>
                            </div>
<!--                            price-->
                            <div class="shop-widget mb--40">
                                <h3 class="widget-title mb--25">Price</h3>
                                <ul class="widget-list price-list">

                                    <li>
                                        <a href="shop.php?priceLow=10&priceHigh=50">
                                            <span>Low - Medium</span>
                                            <strong class="font-weight-medium">$10.00 - $50.00</strong>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="shop.php?priceLow=51&priceHigh=150">
                                            <span>Medium - High</span>
                                            <strong class="font-weight-medium">$51.00 - $150.00</strong>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="shop.php?priceLow=151">
                                            <span>High - Avobe</span>
                                            <strong class="font-weight-medium">$151.00 - Avobe </strong>
                                        </a>
                                    </li>

                                </ul>
                            </div>
<!--                            brand-->
                            <div class="shop-widget mb--40">
                                <h3 class="widget-title mb--25">Brand</h3>
                                <ul class="widget-list brand-list">
                                    <?php
                                        $str="select * from t_dictionary where type='brand'";
                                        $link->query('SET NAMES UTF8');
                                        $tmpResult=$link->query($str);
                                        while($tmpRow = mysqli_fetch_assoc($tmpResult))
                                        {
                                            $str1="select count(*) from v_product where brand=".$tmpRow['id'];
                                            $link->query('SET NAMES UTF8');
                                            $tmpResult1=$link->query($str1);
                                            $tmpRow1 = mysqli_fetch_array($tmpResult1);

                                    ?>
                                    <li>
                                        <a href=<?php echo "shop.php?brand=". $tmpRow['id']?>><?php echo $tmpRow['name']?>

                                            <strong class="color--red font-weight-medium"><?php echo $tmpRow1[0]?></strong>
                                        </a>
                                    </li>
                                        <?php
                                        }
                                    ?>
                                </ul>
                            </div>

                        </aside>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Main Content Wrapper Start -->





    <!-- Searchform Popup Start -->
    <div class="searchform__popup" id="searchForm">
        <a href="#" class="btn-close"><i class="la la-remove"></i></a>
        <div class="searchform__body">
            <p>Start typing and press Enter to search</p>
            <form class="searchform"  action="shop.php">
                <input type="text" name="popup-search" id="popup-search" class="searchform__input" placeholder="Search Entire Store...">
                <button type="submit" class="searchform__submit"><i class="la la-search"></i></button>
            </form>
        </div>
    </div>


    <!-- Searchform Popup End -->

    <!-- Qicuk View Modal Start -->
    <div class="modal fade product-modal" id="productModal" tabindex="-1" role="dialog" aria-hidden="true">

        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class="la la-remove"></i></span>
                    </button>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="element-carousel slick-vertical-center"
                                 data-slick-options='{
                            "slidesToShow": 1,
                            "slidesToScroll": 1,
                            "arrows": true,
                            "prevArrow": {"buttonClass": "slick-btn slick-prev", "iconClass": "la la-angle-double-left" },
                            "nextArrow": {"buttonClass": "slick-btn slick-next", "iconClass": "la la-angle-double-right" }
                        }'
                            >
<!--图片-->
                                <div class="product-image">
                                    <div class="product-image--holder">
                                        <a href="product-details.html">
                                            <img src="assets/img/products/prod-01.jpg" alt="Product Image" class="primary-image">
                                        </a>
                                    </div>
                                    <span class="product-badge sale">sale</span>
                                </div>
                                <div class="product-image">
                                    <div class="product-image--holder">
                                        <a href="product-details.html">
                                            <img src="assets/img/products/prod-02.jpg" alt="Product Image" class="primary-image">
                                        </a>
                                    </div>
                                    <span class="product-badge sale">sale</span>
                                </div>
                                <div class="product-image">
                                    <div class="product-image--holder">
                                        <a href="product-details.html">
                                            <img src="assets/img/products/prod-01.jpg" alt="Product Image" class="primary-image">
                                        </a>
                                    </div>
                                    <span class="product-badge sale">sale</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="modal-box product-summary">

                                <h3 class="product-title mb--20">Golden Easy Spot Chair.</h3>
                                <p class="product-short-description mb--25">Donec accumsan auctor iaculis. Sed suscipit arcu ligula, at egestas magna molestie a. Proin ac ex maximus, ultrices justo eget, sodales orci. Aliquam egestas libero ac turpis pharetra, in vehicula lacus scelerisque. Vestibulum ut sem laoreet, feugiat tellus at, hendrerit arcu.</p>
                                <div class="product-price-wrapper mb--25">
                                    <span class="money">$200.00</span>
                                    <span class="price-separator">-</span>
                                    <span class="money">$400.00</span>
                                </div>
                                <form action="#" class="variation-form mb--30">
                                    <div class="product-color-variations d-flex align-items-center mb--20">
                                        <p class="variation-label">Color:</p>
                                        <div class="product-color-variation variation-wrapper">
                                            <div class="variation">
                                                <a class="product-color-variation-btn red selected" data-toggle="tooltip" data-placement="top" title="Red">
                                                    <span class="product-color-variation-label">Red</span>
                                                </a>
                                            </div>
                                            <div class="variation">
                                                <a class="product-color-variation-btn black" data-toggle="tooltip" data-placement="top" title="Black">
                                                    <span class="product-color-variation-label">Black</span>
                                                </a>
                                            </div>
                                            <div class="variation">
                                                <a class="product-color-variation-btn pink" data-toggle="tooltip" data-placement="top" title="Pink">
                                                    <span class="product-color-variation-label">Pink</span>
                                                </a>
                                            </div>
                                            <div class="variation">
                                                <a class="product-color-variation-btn blue" data-toggle="tooltip" data-placement="top" title="Blue">
                                                    <span class="product-color-variation-label">Blue</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-size-variations d-flex align-items-center mb--15">
                                        <p class="variation-label">Size:</p>
                                        <div class="product-size-variation variation-wrapper">
                                            <div class="variation">
                                                <a class="product-size-variation-btn selected" data-toggle="tooltip" data-placement="top" title="S">
                                                    <span class="product-size-variation-label">S</span>
                                                </a>
                                            </div>
                                            <div class="variation">
                                                <a class="product-size-variation-btn" data-toggle="tooltip" data-placement="top" title="M">
                                                    <span class="product-size-variation-label">M</span>
                                                </a>
                                            </div>
                                            <div class="variation">
                                                <a class="product-size-variation-btn" data-toggle="tooltip" data-placement="top" title="L">
                                                    <span class="product-size-variation-label">L</span>
                                                </a>
                                            </div>
                                            <div class="variation">
                                                <a class="product-size-variation-btn" data-toggle="tooltip" data-placement="top" title="XL">
                                                    <span class="product-size-variation-label">XL</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="" class="reset_variations">Clear</a>
                                </form>
                                <div class="product-action d-flex flex-sm-row flex-column align-items-sm-center align-items-start mb--30">
                                    <div class="quantity-wrapper d-flex align-items-center mr--30 mr-xs--0 mb-xs--30">
                                        <label class="quantity-label" for="quick-qty">Quantity:</label>
                                        <div class="quantity">
                                            <input type="number" class="quantity-input" name="qty" id="quick-qty" value="1" min="1">
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-size-sm btn-shape-square" onclick="window.location.href='#'">
                                        Add To Cart
                                    </button>
                                </div>
                                <div class="product-footer-meta">
                                    <p><span>Category:</span>
                                        <a href="shop.html">Full Sweater</a>,
                                        <a href="shop.html">SweatShirt</a>,
                                        <a href="shop.html">Jacket</a>,
                                        <a href="shop.html">Blazer</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Qicuk View Modal End -->

    <!-- Global Overlay Start -->
    <div class="global-overlay"></div>
    <!-- Global Overlay End -->

    <!-- Global Overlay Start -->
    <a class="scroll-to-top" href=""><i class="la la-angle-double-up"></i></a>
    <!-- Global Overlay End -->
</div>
<!-- Main Wrapper End -->


<!-- ************************* JS Files ************************* -->

<!-- jQuery JS -->
<script src="assets/js/vendor.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>
</body>

</html>
