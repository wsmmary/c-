<?php
//类的用法
// 读取分页类
require './pdo.php';

require './pager.class.php';

$str1 = "select * from v_product";

$link->query('SET NAMES UTF8');

$result1 = $link->query($str1);

///////////////////与分页有关//////////////////////////////
// 这是一个sql查询语句，并得到查询结果
$sql = "select * from v_product ";
// 分页初始化
$page = new pager($link,$sql,6);
// 9是每页显示的数量
$result=$link->query($page->sqlquery());
while($info = mysqli_fetch_assoc($result)) {

    echo $info["id"] . "<br/>";

 echo '<img src="'."assets/img/products/".$info['name'].'.jpg" alt="Product">';


}

echo $page->set_page_info();

?>