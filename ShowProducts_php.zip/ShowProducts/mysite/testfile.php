<html>
<head>
<meta charset="utf-8">

</head>
<body>

<form action="upload_file.php" method="post" enctype="multipart/form-data">
    <label for="file">name:</label>
    <input type="file" name="file" id="file"><br>
    <input type="submit" name="submit" value="submit">
</form>

</body>
</html>