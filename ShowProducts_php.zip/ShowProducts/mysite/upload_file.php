<?php  
$target_path = 'assets/';  

$target_path = $target_path.basename( $_FILES['file']['name']);
//$target_path = $target_path.'image1.jpg';      

echo $target_path;

Print_r(  getimagesize($_FILES["file"]["tmp_name"]));

if(move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {  
    echo "File uploaded successfully!";  
} else{  
    echo "Sorry, file not uploaded, please try again!";  
}  
?>

