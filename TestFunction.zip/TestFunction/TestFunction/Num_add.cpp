#include "pch.h"
#include "Num_add.h"
#include <string>
#include <iostream>
using namespace std;

Num_add::Num_add()
{
}


Num_add::~Num_add()
{
}

int Num_add::CNum_add(int m,int n) {
	num1 = m;
	num2 = n;
	return num1, num2;
}
void Num_add::showsum() {
	
	cout << (num1 + num2) << endl;
}
