#pragma once
class Num_add
{
public:
	int CNum_add(int m, int n);
	Num_add();
	~Num_add();
	void showsum();
private:
	int num1;
	int num2;

};

