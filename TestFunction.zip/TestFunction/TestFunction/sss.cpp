#include "pch.h"
#include "sss.h"
#include <string>
using namespace std;
sss::sss()
{

}

sss::~sss()
{
}
