#pragma once
class sss
{
public:
	sss();
	~sss();
};

