
function ajaxRequest(){
	
	var request = new XMLHttpRequest() 
	
	return request
	
}


function ajaxPOSTRequest(){
	
	request = new ajaxRequest()
	
	request.open("POST", "ajax.php", true)
	
	request.onreadystatechange = function()
	{
		document.getElementById('contentDIV').innerHTML = this.responseText		
	}
	
	request.send("url=ajaxpage.html")
		
}