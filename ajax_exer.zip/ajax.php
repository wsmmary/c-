<?php

	echo 'My Response Text!';


?>