var flag=1;

function checkValid(){
var num1=document.getElementById("num1").value;
var num2=document.getElementById("num2").value;

	//validate Input
	if(num1===""){
		alert("Please enter some value");
		flag=0;
		return;
	}
	if(num2===""){
		alert("Please enter some valued");
		flag=0;
		return;
	}
}
function calculateAdd(){

	if(flag=1){
		var num1=document.getElementById("num1").value;
		var num2=document.getElementById("num2").value;

		var total=Number(num1)+Number(num2);
		
		document.getElementById("result").value=total;
	}
}
function calculateSub(){

	if(flag=1){
		var num1=document.getElementById("num1").value;
		var num2=document.getElementById("num2").value;

		var total=Number(num1)-Number(num2);
		
		document.getElementById("result").value=total;
	}
}
function calculateMul(){

	if(flag=1){
		var num1=document.getElementById("num1").value;
		var num2=document.getElementById("num2").value;

		var total=Number(num1)*Number(num2);
		
		document.getElementById("result").value=total;
	}
}
function calculateDiv(){

	if(flag=1){
		var num1=document.getElementById("num1").value;
		var num2=document.getElementById("num2").value;

		var total=Number(num1)/Number(num2);
		
		document.getElementById("result").value=total;
	}
}
function calculateMod(){

	if(flag=1){
		var num1=document.getElementById("num1").value;
		var num2=document.getElementById("num2").value;

		var total=Number(num1)%Number(num2);
		
		document.getElementById("result").value=total;
	}
}
//click to call add function
document.getElementById("add").onclick=function(){
	checkValid();
	calculateAdd();
}
//click to call sub function
document.getElementById("sub").onclick=function(){
	checkValid();
	calculateSub();
}
//click to call mul function
document.getElementById("mul").onclick=function(){
	checkValid();
	calculateMul();
}
//click to call div function
document.getElementById("div").onclick=function(){
	checkValid();
	calculateDiv();
}
//click to call mod function
document.getElementById("mod").onclick=function(){
	checkValid();
	calculateMod();
}