<?php

$config = include 'Config.php';

$m=new Model($config);

// $m->limit('0,5')->table('user')->field('age,name')->order('money desc')->where('id>1')->select();
// var_dump($m->sql);

// var_dump($m->field('name')->table('user')->limit('0,2')->where('id>0')->order('age desc')->select());
// var_dump($m->sql);


// $data=['age'=>30,'name'=>'jack','money'=>2000];
// $insertID=$m->table('user')->insert($data);
// var_dump($insertID);

//var_dump($m->table('user')->where('id=3')->delete());

// $data=['name'=>'andy','money'=>3000];
// var_dump($m->table('user')->where('id=2')->update($data));


//var_dump($m->table('user')->max('money'));

var_dump($m->getByName('jack'));
class Model
{
	protected $host;
	protected $user;
	protected $pwd;
	protected $dbname;
	protected $charset;
	protected $prefix;
	protected $link;
	protected $tableName='user';
	protected $sql;
	protected $options;  //array. save all the condition

	function __construct($config){
		$this->host=$config['DB_HOST'];
		$this->user=$config['DB_USER'];
		$this->pwd=$config['DB_PWD'];
		$this->dbname=$config['DB_NAME'];
		$this->charset=$config['DB_CHARSET'];
		$this->prefix=$config['DB_PREFIX'];

		//connect database
		$this->link=$this->connect();

		//get the table name
		$this->tableName=$this->getTableName();

		//initial options array
		$this->initOptions();

	}

	protected function initOptions(){
		$arr=['where','table','field','order','group','having','limit'];
		foreach ($arr as $key => $value) {
			$this->options[$value]='';
			if($value=='table'){
				$this->options[$value]=$this->tableName;
			}else if($value=='field'){
				$this->options[$value]='*';
			}
		}

	}

	protected function getTableName(){
		//if having setup the member variables
		if(!empty($this->tableName)){
			return $this->prefix.$this->tableName;
		}
		//if have not setup the member variables
		$className=get_class($this);
		$table=strtolower(substr($className, 0,-5));
		return $this->prefix.$table;
	}

	protected function connect(){
		$link=mysqli_connect($this->host,$this->user,$this->pwd);
		if(!$link){
			die('connection is failed');
		}
		mysqli_select_db($link,$this->dbname);
		mysqli_set_charset($link,$this->charset);
		return $link;
	}

	//filed
	function field($field){
		if(!empty($field)){
			if(is_string($field)){
				$this->options['field']=$field;
			}else if(is_array($field)){
				$this->options['field']=join(',',$field);
			}
		}
		return $this;
	}
	
	//table
	function table($table){
		if(!empty($table)){
			$this->options['table']=$table;
		}
		return $this;
	}

	//where
	function where($where){
		if(!empty($where)){
			$this->options['where']='where '.$where;
		}
		return $this;
	}

	//group
	function group($group){
		if(!empty($group)){
			$this->options['group']='group by '.$group;
		}
		return $this;
	}

	//having
	function having($having){
		if(!empty(having)){
			$this->options['having']='having '.$having;
		}
		return $this;
	}

	//order
	function order($order){
		if(!empty($order)){
			$this->options['order']='order by '.$order;
		}
		return $this;
	}

	//limit
	function limit($limit){
		if(!empty($limit)){
			if(is_string($limit)){
				$this->options['limit']='limit '.$limit;
			}else if(is_array($limit)){
				$this->options['limit']='limit '.join(',',$limit);
			}
			
		}
		return $this;
	}

	//select
	function select(){
		$sql='select %FIELD% from %TABLE% %WHERE% %GROUP% %HAVING% %ORDER% %LIMIT%';

		$sql=str_replace(['%FIELD%','%TABLE%','%WHERE%','%GROUP%','%HAVING%','%ORDER%','%LIMIT%'], [$this->options['field'],$this->options['table'],$this->options['where'],$this->options['group'],$this->options['having'],$this->options['order'],$this->options['limit']], $sql);

		$this->sql=$sql;

		return $this->query($sql);

	}

	//query
	function query($sql){
		//$this->initOptions();   //clean

		$result=mysqli_query($this->link,$sql);
		if($result && mysqli_affected_rows($this->link)){
			while ($data=mysqli_fetch_assoc($result)) {
				$newData[]=$data;
			}
		}
		return $newData;
	}

	//exec
	function exec($sql,$isInsert=false){
		$this->initOptions();   //clean

		$result=mysqli_query($this->link,$sql);
		if($result && mysqli_affected_rows($this->link)){
			if($isInsert){
				return mysqli_insert_id($this->link);
			}else{
				return mysqli_affected_rows($this->link);
			}
		}
		return false;
	}
	function __get($name){
		if($name=='sql'){
			return $this->sql;
		}
		return false;
	}

	//insert   $data is an association array
	function insert($data){
		$data=$this->parseValue($data);

		$keys=array_keys($data);
		$values=array_values($data);

		$sql='insert into %TABLE%(%FIELD%) values(%VALUES%)';
		$sql=str_replace(['%TABLE%','%FIELD%','%VALUES%'], [$this->options['table'],join(',',$keys),join(',',$values)], $sql);
		$this->sql=$sql;
		return $this->exec($sql,true);
	}

	protected function parseValue($data){
		foreach ($data as $key => $value) {
			if(is_string($value)){
				$value='"'.$value.'"';
			}
			$newData[$key]=$value;
		}
		return $newData;
	}

	function delete(){
		$sql='delete from %TABLE% %WHERE%';
		$sql=str_replace(['%TABLE%', '%WHERE%'],[$this->options['table'],$this->options['where']],$sql);
		$this->sql=$sql;
		return $this->exec($sql);
	}

	function update($data){
		$data=$this->parseValue($data);
		$value=$this->parseUpdate($data);
		$sql='update %TABLE% set %VALUES% %WHERE%';
		$sql=str_replace(['%TABLE%','%VALUES%','%WHERE%'], [$this->options['table'],$value,$this->options['where']], $sql);
		$this->sql=$sql;
		return $this->exec($sql);
	}

	protected function parseUpdate($data){
		foreach ($data as $key => $value) {
			$newData[]=$key.'='.$value;
		}
		return join(',',$newData);
	}

	function max($field){
		$result=$this->field('max('.$field.') as max')->select();

		return $result[0]['max'];
	}

	function __destruct(){
		mysqli_close($this->link);
	}

	//getByName getByAge
	function __call($name,$args){
		$str=substr($name,0,5);
		$field=strtolower(substr($name,5));
		if($str=='getBy'){
			return $this->where($field.'="'.$args[0].'"')->select();
		}
		return false;
	}

}


?>
