<?php

namespace controller;
class IndexController
{
	function index(){
		echo 'This is index method<br/>';
	}

	function demo(){
		echo 'This is demo method<br/>';
	}
}
?>