<?php
//index.php?m=index&a=index
//index.php?m=index&a=demo
class Psr4AutoLoad{
	function __construct(){
		spl_autoload_register([$this,'autoload']);
	}

	function autoload($className){
		// echo $className;
		//finding the file according to the class name and then include it
		$filePath=str_replace('\\', '/', $className).'.php';
		include $filePath;
	}
}

$psr=new Psr4AutoLoad();
//get the name of controller and name of the method
$m=$_GET['m'];

$className='controller\\'.ucfirst(strtolower($m)).'Controller';

$obj=new $className();
//var_dump($obj);
$a=$_GET['a'];

call_user_func([$obj,$a]);

?>