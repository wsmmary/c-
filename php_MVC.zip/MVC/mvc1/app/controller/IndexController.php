<?php
namespace controller;
class IndexController{
	function index(){
		echo "This is index method";
	}
	function demo(){
		echo 'This is demo method<br/>';
	}
}

?>