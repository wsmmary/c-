<?php
class Psr4Autoload{
	//namespace map
	protected $maps=[];
	function __construct(){
		spl_autoload_register([$this,'autoload']);
	}

	function autoload($className){
		//namespace+classname
		$pos=strrpos($className,'\\');
		$namespace=substr($className, 0,$pos);
		$realClass=substr($className,$pos+1);
		$this->mapLoad($namespace,$realClass);

	}

	protected function mapLoad($namespace,$realClass){
		if(array_key_exists($namespace, $this->maps)){
			$namespace=$this->maps[$namespace];
		}

		$namespace=rtrim(str_replace('\\/', '/', $namespace),'/').'/';
		$filePath=$namespace.$realClass.'.php';
		if(file_exists($filePath)){
			include $filePath;	
		}else{
			die('The file is not exist');
		}
		
	}

	function addMaps($namespace,$path){
		if(array_key_exists($namespace, $this->maps)){
			die('This namespace exsit');
		}
		$this->maps[$namespace]=$path;
	}
}
?>