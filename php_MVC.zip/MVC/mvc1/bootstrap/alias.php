<?php
Start::$auto->addMaps('controller','app/controller');
?>