<?php
include 'bootstrap/Psr4Autoload.php';
include 'bootstrap/Start.php';
include 'bootstrap/alias.php';


Start::router();
?>