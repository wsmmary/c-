<?php

class Tpl{
	//the template path
	protected $viewDir='./view';

	//cach path
	protected $cacheDir='./cache/';

	//expire 
	protected $lifeTime=3600;

	//variable array
	protected $vars=[];

	
	function __construct($viewDir=null,$cacheDir=null,$lifeTime=null){
		if(!empty($viewDir)){
			if($this->checkDir($viewDir)){
				$this->viewDir=$viewDir;
			}
		}
		if(!empty($cacheDir)){
			if($this->checkDir($cacheDir)){
				$this->cacheDir=$cacheDir;
			}
		}
		if(!empty($lifeTime)){
			$this->lifeTime=$lifeTime;
		}
	}

	protected function checkDir($dirPath){
		if(!file_exists($dirPath) || is_dir($dirPath)){
			return mkdir($dirPath,0755,true);
		}
		if(!is_writable($dirPath) || is_readable($dirPath)){
			return chmod($dirPath, 0755);
		}
		return true;
	}

	//allocate variable
	function assign($name,$value){
		//var_dump($value);
		$this->vars[$name]=$value;
		//var_dump($this->vars);
	}

	//show cach file
	function display($viewName,$isInclude=true,$uri=null){
		//make the template file
		$viewPath=rtrim($this->viewDir,'/').'/'.$viewName;
		//var_dump($viewPath);
		if(!file_exists($viewPath)){
			die('The template is not exist.');
		}

		//make the cache file
		$cacheName=md5($viewName.$uri).'.php';
		$cachePath=rtrim($this->cacheDir,'/').'/'.$cacheName;

		//check whether the cache file is exist or not
		if(!file_exists($cachePath)){
			//compile the template file 
			$php=$this->compile($viewPath);
			//write into the cache file
			file_put_contents($cachePath, $php);
		}else{
			$isTimeout=(filectime($cachePath)+$this->lifeTime)>time() ? false : true;
			$isChange=filemtime($viewPath)>filemtime($cachePath) ? true : false;
			if($isTimeout || $isChange){
				$php=$this->compile($viewPath);
				file_put_contents($cachePath, $php);
			}
		}

		//if the cache file need to be included
		if($isInclude){
			extract($this->vars);
			include $cachePath;
		}


	}

	protected function compile($filePath){
		$html=file_get_contents($filePath);
		$array=[
			'{$%%}'=>'<?=$\1;?>',
			'{foreach %%}'=>'<?php foreach(\1): ?>',
			'{/foreach}'=>'<?php endforeach?>',
			'{include %%}'=>'',
			'{if %%}'=>'<?php if(\1):?>',];

		foreach ($array as $key => $value) {
			$pattern='#'.str_replace('%%', '(.+?)', preg_quote($key,'#')).'#';

			if(strstr($pattern,'include')){
				$html=preg_replace_callback($pattern, [$this,'parseInclude'], $html);
			}else{
               	$html=preg_replace($pattern, $value,$html);
			}
		}
		return $html;
	}	

	protected function parseInclude($data){
		$fileName=trim($data[1],'\'"');

		$this->display($fileName,false);

		$cacheName=md5($fileName).'.php';
		$cachePath=rtrim($this->cacheDir,'/').'/'.$cacheName;
		return '<?php include "'.$cachePath.'"?>';
	}

}
?>
