<?php
include 'Tpl.php';
$tpl=new Tpl();
$title='hello';
$data=['Sumei','Dainl'];
$abc='test';
$tpl->assign('abc',$abc);
$tpl->assign('title',$title);
$tpl->assign('data',$data);

$tpl->display('test.html');

?>