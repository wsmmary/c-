<?php
$up=new Upload();
$up->uploadFile('fm');

var_dump($up->errorNumber);
var_dump($up->errorInfo);

class Upload{
	protected $path='./upload/';   //the path 
	protected $allowSuffix=['jpg','jpeg','gif','wbmp','png']; //allows suffix of file
	protected $allowMime=['image/jpeg','image/gif','image/wbmp','image/png'];  //allows mine of file
	protected $maxSize=2000000;  //allows the file size
	protected $isRandName=true; //whether using the random name
	protected $prefix='up_';  //whether using the prefix

	//error number and error information
	protected $errorNumber;
	protected $errorInfo;

	//the information of file
	protected $oldName;
	protected $suffix;
	protected $size;
	protected $mime;
	protected $tmpName;

	//the new file name
	protected $newName;

	public function __construct($arr=[]){
		foreach ($arr as $key => $value) {
			$this->setOption($key,$value);
		}
	}

	//check if the $key is one of the properties.If it is then setup.
	protected function setOption($key,$value){
		//get all the properties
		$keys=array_keys(get_class_vars(__CLASS__));
		if(in_array($key, $keys)){
			$this->$key=$value;
		}
	}

	//upload file 
	//$key is the name of input
	public function uploadFile($key){
		//check whether set up the path or not
		if(empty($this->path)){
			$this->setOption('errorNumber',-1);
			return false;
		}


		//check whether the path is exist or not
		if(!$this->check()){
			$this->setOption('errorNumber',-2);
			return false;
		}

		//check the error information of $_FILES, it is 0 then all information of file are correct  on server side.
		$error=$_FILES[$key]['error'];
		if($error){
			$this->setOption('errorNumber',$error);
			return false;
		}else{
			$this->getFileInfo($key);
		}

		//check the size, mime, suffix of file 
		if(!$this->checkSize() || !$this->checkMime() || !$this->checkSuffix() ){
			return false;
		}

		//get the new file name(whether creating new name in random)
		$this->newName=$this->createNewName();

		//check if uploading the file and move the file
		if(is_uploaded_file($this->tmpName)){
			if(move_uploaded_file($this->tmpName, $this->path.$this->newName)){
				return $this->path.$this->newName;
			}else{
				$this->setOption('errorNumber',-7);
			}

		}else{
			$this->setOption('errorNumber',-6);
		}
	}	

	protected function check(){
		//the folder is not exist
		if(!file_exists($this->path) || !is_dir($this->path)){
			return mkdir($this->path,0777,true);
		}

		if(!is_writable($this->path)){
			return chmod($this->path, 0777);
		}

		return true;
	}

	protected function getFileInfo($key){
		//get the file name
		$this->oldName=$_FILES[$key]['name'];
		$this->mime=$_FILES[$key]['type'];
		$this->tmpName=$_FILES[$key]['tmp_name'];
		$this->size=$_FILES[$key]['size'];
		$this->suffix=pathinfo($this->oldName)['extension'];

	}

	protected function checkSize(){
		if($this->size>$this->maxSize){
			$this->setOption('errorNumber',-3);
			return false;
		}
		return true;
	}

	protected function checkMime(){
		if(!in_array($this->mime, $this->allowMime)){

			$this->setOption('errorNumber',-4);
			return false;
		}
		return true;

	}

	protected function checkSuffix(){
		if(!in_array($this->suffix, $this->allowSuffix)){
			$this->setOption('errorNumber',-5);
			return false;
		}
		return true;

	}

	protected function createNewName(){
		if($this->isRandName){
			$name=$this->prefix.uniqid().'.'.$this->suffix;
		}else{
			$name=$this->prefix.$this->oldName;
		}
		return $name;
	}

	public function __get($name){
		if($name=='errorNumber'){
			return $this->errorNumber;
		}else if($name=='errorInfo'){
			return $this->getErrorInfo();
		}
	}

	protected function getErrorInfo(){
		switch ($this->errorNumber) {
			case -1:
				$str="Do not setup file path";
				break;
			case -2:
				$str="Do not have the authority";
				break;
			case -3:
				$str="The file size exceed the specific range";
				break;
			case -4:
				$str="The file type is not be supported";
				break;
			case -5:
				$str="The suffix is not correct";
				break;
			case -6:
				$str="It is not the upload file";
				break;
			case -7:
				$str='Upload file failed';
				break;
			case 1:
				$str='The uploaded file exceeds the upload_max_filesize directive in php.ini';
				break;
			case 2:
				$str='The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form';
				break;
			case 3:
				$str='The uploaded file was only partially uploaded.';
				break;
			case 4:
				$str='No file was uploaded. ';
				break;
			case 6:
				$str='Missing a temporary folder. Introduced in PHP 5.0.3.';
				break;
			case 7:
				$str='Failed to write file to disk. Introduced in PHP 5.1.0. ';
				break;
			case 8:
				$str='A PHP extension stopped the file upload.';
				break;
		}
		return $str;
	}
}
?>