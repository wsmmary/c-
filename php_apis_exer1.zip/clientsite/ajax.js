
function ajaxRequest(){
	
	var request = new XMLHttpRequest() 
	
	return request
	
}


function ajaxPOSTRequest(){
	
	request = new ajaxRequest()
	
	request.open("GET", "http://localhost/mysite/controllers/cdscontroller.php", true)
	
	request.onreadystatechange = function()
	{
		document.getElementById('contentDIV').innerHTML = this.responseText		
	}
	
	request.send("url=view.html")
		
}