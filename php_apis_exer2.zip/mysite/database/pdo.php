<?php

	$host = 'localhost';
	$database = 'mydb';
	$user = 'root';
	$password = '';


	$query = "select * from cds";
	

         
    $conn = new PDO("mysql:host=$host;dbname=$database",$user,$password);


	$statement = $conn->prepare($query);
	
	$statement->execute();
	
	echo $statement->rowCount();

	echo '<br/>';
	
	echo $statement->fetch(PDO::FETCH_ASSOC)['TITLE'];

?>