<?php

/*	echo 'Index.php';
	echo '<br/>';
	echo $_SERVER['REQUEST_METHOD'];
	
	echo '<br/>';
	
	echo $_SERVER['PATH_INFO'];
	*/
	
	spl_autoload_register('autoLoad');
	
	function autoLoad($classname){
		
	    if (preg_match('/[a-zA-Z]+Controller$/', $classname)) {
	        include __DIR__ . '/controllers/' . $classname . '.php';
	        return true;
	    } elseif (preg_match('/[a-zA-Z]+Model$/', $classname)) {
	        include __DIR__ . '/models/' . $classname . '.php';
	        return true;
	    } elseif (preg_match('/[a-zA-Z]+View$/', $classname)) {
	        include __DIR__ . '/views/' . $classname . '.php';
	        return true;
	    }
		
	}
	
	
	class Request {
		
		// Http action/verb/method
		$Verb; 
		
		$URL_Elements;
		
		$Parameters;
		
		 public function __construct() {
		 	
		 	$this->Verb = $_SERVER['REQUEST_METHOD'];
		 	
		 
		 	// http://localhost/mysite/cd/123
		 	// The URL will be redirected to http://localhost/mysite/index.php/cd/123
		 	// The PATH_INFO is /cd/123
		 	// Split the requested URL elements into an array
		 	$this->url_elements = explode('/', $_SERVER['PATH_INFO']);
		 	
		 }
		
	}

?>