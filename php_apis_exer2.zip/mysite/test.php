<?php


	$string = '/cd/123';
	
	 $result = explode('/', $string);
	 
	 print_r($result);
		
	
?>