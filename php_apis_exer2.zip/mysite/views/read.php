<?php

	require_once('../model/cd.php');
	
	$cd = new cd();

	echo json_encode($cd->getAllCDS());
	

?>