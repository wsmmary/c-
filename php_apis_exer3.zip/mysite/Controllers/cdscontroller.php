<?php
	
	
//	spl_autoload_register('autoLoad');
	
//	function autoLoad(){
		
		require_once('../model/cd.php');
		
	//}
	
	class CDSController{
		
		private $CD;
		
		function getData(){
			
			$CD = new cd();
			
			return $CD->getAllCDS();
			
		}
									
	}

	$CDSController = new CDSController();
	
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Origin: *");

	echo json_encode($CDSController->getData());

?>