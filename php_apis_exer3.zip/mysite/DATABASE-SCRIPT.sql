

CREATE TABLE `CDS` (
  `CD_NUMBER` int(5) NOT NULL,
  `TITLE` varchar(50) NOT NULL,
  `PRODUCER` varchar(50) NOT NULL,
  `YEAR` varchar(4) NOT NULL
);

ALTER TABLE `cds`
  ADD PRIMARY KEY (`CD_NUMBER`);
COMMIT;


INSERT INTO cds(cd_number,title,producer,year)
VALUES(90,'The Celebrants Live in Concert','Old Town Records','1997');
INSERT INTO cds(cd_number,title,producer,year)
VALUES(91,'Party Music for All Occasions','The Music Man','2000');
INSERT INTO cds(cd_number,title,producer,year)
VALUES(92,'Back to the Shire','Middle Earth Records','2002');
INSERT INTO cds(cd_number,title,producer,year)
VALUES(93,'Songs from My Childhood','Old Town Records','1999');
INSERT INTO cds(cd_number,title,producer,year)
VALUES(94,'Carpe Diem','R & B Inc.','2000');
INSERT INTO cds(cd_number,title,producer,year)
VALUES(95,'Here Comes the Bride','The Music Man','2001');
INSERT INTO cds(cd_number,title,producer,year)
VALUES(96,'Graduation Songbook','Tunes Are Us','1998');
INSERT INTO cds(cd_number,title,producer,year)
VALUES(98,'Whirled Peas','Old Town Records','2004');