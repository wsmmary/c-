<?php

/*	echo 'Index.php';
	echo '<br/>';
	echo $_SERVER['REQUEST_METHOD'];
	
	echo '<br/>';
	
	echo $_SERVER['PATH_INFO'];
	*/
	
	spl_autoload_register('autoLoad');
	
	function autoLoad($classname){
		
	    if (preg_match('/[a-zA-Z]+Controller$/', $classname)) {
	        include __DIR__ . '/controllers/' . $classname . '.php';
	        return true;
	    } elseif (preg_match('/[a-zA-Z]+Model$/', $classname)) {
	        include __DIR__ . '/models/' . $classname . '.php';
	        return true;
	    } elseif (preg_match('/[a-zA-Z]+View$/', $classname)) {
	        include __DIR__ . '/views/' . $classname . '.php';
	        return true;
	    }
		
	}
	
	
	class Request {
		
		// Http action/verb/method
		$Verb; 
		
		// Path Info
		$URL_Elements;
		
		// Could be query string or 
		// from the HTTP Request Body (mostly in case of POST or PUT)
		$Parameters;
		
		// format
		$format = 'json';
		
		
		 public function __construct() {
		 	
		 	$this->Verb = $_SERVER['REQUEST_METHOD'];
		 	
		 
		 	// http://localhost/mysite/cd/123
		 	// The URL will be redirected to http://localhost/mysite/index.php/cd/123
		 	// The PATH_INFO is /cd/123
		 	// Split the requested URL elements into an array
		 	$this->URL_Elements = explode('/', $_SERVER['PATH_INFO']);
		 
		 
		 	$this->parseIncomingParams();
		 
		 
		 
		 	return true;
		 }
		 
		 function parseIncomingParams(){
		 	
		 	 $Parameters = array();
		 	 
	        // first of all, pull the GET vars
	        // We could get these parameters from the $_GET super gloabal array
	        if (isset($_SERVER['QUERY_STRING'])) {
	            parse_str($_SERVER['QUERY_STRING'], $Parameters);
	        }
	        
	        // We could add a try catch and error handling
	        $body = file_get_contents("php://input"); 	 

			$content_type = false;
			
			
			// $_SERVER['CONTENT_TYPE'] is the content type requested by the browser part of the HTTP Request
	        if(isset($_SERVER['CONTENT_TYPE'])) {
	            $content_type = $_SERVER['CONTENT_TYPE'];
	        }
	        
	        // We assume that the CONTENT_TYPE determines the type of data sent in the request body
	        
	        switch($content_type) {
	            case "application/json":
	           	
	           	 $body_params = json_decode($body);
	           	 
                if($body_params) {
					
					// Add the body parameters to the parameters we got from the query string
					$Parameters = array_merge($Parameters, $body_params);
							
                }
                
                $this->format = "json";
                break;
                
                case "application/x-www-form-urlencoded": 
                            	 
	           		 parse_str($body, $postvars);
	           		 
	           		 $Parameters = array_merge($Parameters, $postvars);
	           		 
	                $this->format = "html";
	                break;	
	                
	            default:
	            	// handle other formats
             	   break;	            	           		 
	           		 
	         }	
	         
	       $this->Parameters = $Parameters;         

		 }	
	}// End Request Class
	
	$Request = new Request();
	
	$Result = "";
	
	// route the request to the right place / controller
	$controller_name = ucfirst($Request->url_elements[1]) . 'Controller';
	
	if (class_exists($controller_name)) {
		
   		$controller = new $controller_name();
   		
   		$action_name = strtolower($Request->verb) . 'Action';
   		
   		$Result = $controller->$action_name($Request);
   		
	}	
	

?>