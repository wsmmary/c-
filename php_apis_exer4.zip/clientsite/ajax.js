
function ajaxRequest(){
	
	var request = new XMLHttpRequest() 
	
	return request
	
}


function ajaxPOSTRequest(){
	
	request = new ajaxRequest()
	
	request.open("GET", "http://localhost/mysite/cd/90", true)
	
	request.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
	
	request.onreadystatechange = function()
	{
		document.getElementById('contentDIV').innerHTML = this.responseText
	}
	
	request.send("url=view.html")
		
}