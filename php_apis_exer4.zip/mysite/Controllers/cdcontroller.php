<?php

	spl_autoload_register('autoLoadC');
	
	function autoLoadC($classname){

		require_once('./model/cd.php');
		
	}

	class CDController {
		
		private $CD;
		
		public function getAction($request) {

			if(isset($request->URL_Elements[2])) {
				
				$cd_id = (int)$request->URL_Elements[2];
				
				$CD = new cd();
				
				$data = $CD->getCDByID($cd_id);
				
				// If we successfully retrieved the data:
				$data["message"] = "success";

			} else {
				$data["message"] = "invalid request: missing CD ID";
			}	
			
			return $data;
		}
		
		public function postAction($request) {
		
			// Just for the sake of the example we are doing the same as getAction
			// In case the CD ID was submitted in a POST request body we use the Parameters array
			if(isset($request->URL_Elements[2])) {
				
				$cd_id = (int)$request->URL_Elements[2];

				$CD = new cd();
				
				$data = $CD->getCDByID($cd_id);
				
				$data["message"] = "success";

			} else {
				$data["message"] = "invalid request";
			}
			
			return $data;				
		
		}		
		
	}




?>