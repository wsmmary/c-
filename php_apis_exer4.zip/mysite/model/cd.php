<?php

	require_once(dirname(__DIR__).'/database/connectionManager.php');

	class cd{
		
		private $conn;
		
		public $cd_number;
		public $title;
		public $producer;
		public $year;
		
		
		function __construct(){
			
			$connManager = new ConnectionManager();
			
			$this->conn = $connManager->getConnection();
			
		}
		
		function getAllCDS(){
			
			$query = "select * from cds";
			
			$statement = $this->conn->prepare($query);
			
			$statement->execute();
			
			return $statement->fetchAll(PDO::FETCH_ASSOC);
			
		}
		
		function getCDByID($cd_id){
			
			$query = "select * from cds where CD_NUMBER = $cd_id";
			
			$statement = $this->conn->prepare($query);
			
			$statement->execute();
			
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		
	}

?>