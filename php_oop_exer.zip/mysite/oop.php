<?php

	include_once('person.php');


class MyClass{
	
	// Constructor
	// use the class name MyClass OR __construct
	function __construct(){
		
		echo '</br>';
		echo 'a MyClass instance is created!';
		echo '</br>';
	}
	
	// destructor
	function __destruct(){
		//echo 'MyClass instance was deleted';
	}
	
	function defaultParams($p1 = 'd1', $p2 = 'd2'){
		
		echo '</br>';

		echo $p1.'-'.$p2;
		
		echo '</br>';
	}	
	
	public $field1;
	
	// Constants
	const CONSTANT = "constant value";
	
	public static $staticField = 'Static Field';
	
	function myFunction(){
		
		echo '</br>';
		echo 'myFunction!';
		echo '</br>';
		
	}
	
	function returnFunction($p){
		
		return $p + 10;
	}
	
	static function staticFunction(){
		
		echo '</br>';
		echo 'staticFunction!';
		echo '</br>';		
		
	}
	
	function printConstant(){
		
		echo '</br>';
		echo self::CONSTANT;
		echo '</br>';	
	}
	
}// MyClass

	// Create a MyClass instance
	$myClass = new MyClass();

	$myClass->field1 = 125;
	echo $myClass->field1;
	
	echo' </br>';
	
	// Calling a function inside a Class
	$myClass->myFunction();

	echo' </br>';
	
	echo $myClass->returnFunction(10);
	
	
	// Copying Objects
	$myClassA = new MyClass;
	
	$myClassA = $myClass;
	
	$myClassA->field1 = 500;
	
	echo '</br>';
	
	echo $myClass->field1;// field1 also changed when accessed through $myClass because it is pointing to the same memory location as $myClassA
	
	// Cloning
	$myClassA = clone $myClass;
	
	$myClassA->field1 = 1000;
	
	echo '</br>';
	
	echo $myClass->field1;// the value would not change
	
	// Accessing a static field
	echo '</br>';
	echo MyClass::$staticField;
	
	// Calling a static function
	MyClass::staticFunction();
	
	// Using the constructor with parameters
	$myClassB = new MyClass();
	
	$myClassB->defaultParams('p1');
	
	$myClassB = null;
	
	// $myClassB is not usable anymore
	//$myClassB->defaultParams('p1'); 
	// the above call will give an error
	
	
	// Explicitly call the Garbage Collector
	// gc_collect_cycles();
	
	
	// Accessing constants
	echo '</br>';
	echo MyClass::CONSTANT;
	echo '</br>';
	$myClass->printConstant();
	
	
	// Use the class Person from person.php
	
	$person = new Person();
	
	$person->FName = "John";
	$person->LName = "Smith";
	
	echo $person->getFullName();
	
	
?>