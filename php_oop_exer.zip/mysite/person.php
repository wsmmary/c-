<?php

class Person{
	
	function __construct(){
		
	}
	
	public $FName;
	public $LName;
	
	function getFullName(){
		
		$FName = "Steve";
		
		return $FName.' '.$this->LName;
		
	}	
}
?>